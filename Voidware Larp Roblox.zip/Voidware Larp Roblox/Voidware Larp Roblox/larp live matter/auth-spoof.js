(function() {
    'use strict';

    function getCookie(name) {
        var m = document.cookie.match(new RegExp('(?:^|; )' + name.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '=([^;]*)'));
        return m ? decodeURIComponent(m[1]) : '';
    }

    var FAKE_USERID = getCookie('__blf_uid');
    var FAKE_USERNAME = getCookie('__blf_uname');
    var FAKE_DISPLAY_NAME = getCookie('__blf_dname');
    var FAKE_VERIFIED = getCookie('__blf_verified') === '1';
    var REAL_USERID = getCookie('__blf_ruid');

    var FULL_SPOOF = !!(FAKE_USERID && FAKE_USERNAME);

    function badgeToggleOn() {
        try { return localStorage.getItem('lawi_verified_toggle') === '1'; } catch(e) { return false; }
    }

    function premiumToggleOn() {
        try { return localStorage.getItem('lawi_premium_toggle') === '1'; } catch(e) { return false; }
    }

    var capturedRealUserId = REAL_USERID || '';

    if (typeof window.fetch !== 'function') return;

    var realFetch = window.fetch.bind(window);
    var realXHROpen = XMLHttpRequest.prototype.open;
    var realXHRSend = XMLHttpRequest.prototype.send;
    var realResponseDesc = Object.getOwnPropertyDescriptor(XMLHttpRequest.prototype, 'response');
    var realResponseTextDesc = Object.getOwnPropertyDescriptor(XMLHttpRequest.prototype, 'responseText');

    if (!realFetch || !realXHROpen || !realXHRSend) return;

    function spoofAuthData(data) {
        if (!data || typeof data !== 'object') return data;
        if (data.id) capturedRealUserId = data.id.toString();
        if (FULL_SPOOF) {
            data.name = FAKE_USERNAME;
            data.displayName = FAKE_DISPLAY_NAME;
        }
        var toggle = badgeToggleOn();
        data.hasVerifiedBadge = toggle ? true : (FULL_SPOOF ? FAKE_VERIFIED : data.hasVerifiedBadge);
        if (premiumToggleOn()) {
            data.isPremium = true;
            data.premiumMembership = data.premiumMembership || { membershipType: 4 };
        }
        return data;
    }

    function spoofPremiumFeatures(data) {
        if (!premiumToggleOn()) return data;
        if (!data || typeof data !== 'object') return data;
        /* /v1/users/{id}/validate-membership → { isPremium: true } */
        if (typeof data.isPremium !== 'undefined') data.isPremium = true;
        /* /v1/premium-features/subscriptions → array of active subs */
        if (Array.isArray(data)) {
            if (data.length === 0) {
                data.push({ productId: 1, premiumFeatureId: 1, membershipType: 4, durationType: 1, isActive: true });
            }
        }
        return data;
    }

    function isPremiumApi(url) {
        return url && (
            url.includes('/premium-features/') ||
            url.includes('/validate-membership') ||
            url.includes('/membership')
        );
    }

    function rewriteUserId(str) {
        if (!capturedRealUserId || !str) return str;
        return str.replace(new RegExp(capturedRealUserId, 'g'), FAKE_USERID);
    }

    function isAuthApi(url) {
        return url && url.includes('/v1/users/authenticated');
    }

    function isThumbnailApi(url) {
        return url && url.includes('thumbnails.roblox.com');
    }

    function isUserInfoApi(url) {
        return url && url.includes('/oauth/') && url.includes('/userinfo');
    }

    function rewriteBatchBody(body) {
        if (!body || !capturedRealUserId) return body;
        try {
            var parsed = JSON.parse(typeof body === 'string' ? body : '');
            if (Array.isArray(parsed)) {
                var changed = false;
                parsed.forEach(function(item) {
                    if (item.targetId && item.targetId.toString() === capturedRealUserId) {
                        item.targetId = parseInt(FAKE_USERID);
                        changed = true;
                    }
                });
                if (changed) return JSON.stringify(parsed);
            }
        } catch(e) {}
        return body;
    }

    window.fetch = function() {
        var args = Array.prototype.slice.call(arguments);
        var urlString = '';
        try {
            var first = args[0];
            urlString = typeof first === 'string' ? first : (first instanceof Request ? first.url : String(first));
        } catch(e) {
            return realFetch.apply(this, args);
        }

        if (isAuthApi(urlString)) {
            return realFetch.apply(this, args).then(function(response) {
                return response.clone().json().then(function(data) {
                    return new Response(JSON.stringify(spoofAuthData(data)), {
                        status: response.status, statusText: response.statusText, headers: response.headers
                    });
                }).catch(function() { return response; });
            });
        }

        if (isPremiumApi(urlString)) {
            return realFetch.apply(this, args).then(function(response) {
                return response.clone().json().then(function(data) {
                    return new Response(JSON.stringify(spoofPremiumFeatures(data)), {
                        status: response.status, statusText: response.statusText, headers: response.headers
                    });
                }).catch(function() { return response; });
            });
        }

        if (isUserInfoApi(urlString)) {
            return realFetch.apply(this, args).then(function(response) {
                return response.clone().json().then(function(data) {
                    if (data && typeof data === 'object') {
                        if (data.sub) data.sub = FAKE_USERID;
                        if (data.name) data.name = FAKE_USERNAME;
                        if (data.nickname) data.nickname = FAKE_USERNAME;
                        if (data.preferred_username) data.preferred_username = FAKE_USERNAME;
                        if (data.profile) data.profile = 'https://www.roblox.com/users/' + FAKE_USERID + '/profile';
                        if (data.picture && capturedRealUserId) data.picture = rewriteUserId(data.picture);
                    }
                    return new Response(JSON.stringify(data), {
                        status: response.status, statusText: response.statusText, headers: response.headers
                    });
                }).catch(function() { return response; });
            });
        }

        if (isThumbnailApi(urlString)) {
            var newUrl = rewriteUserId(urlString);
            if (newUrl !== urlString) {
                var newArgs = args.slice();
                if (typeof newArgs[0] === 'string') {
                    newArgs[0] = newUrl;
                } else if (newArgs[0] instanceof Request) {
                    newArgs[0] = new Request(newUrl, newArgs[0]);
                }
                var opts = newArgs[1] || {};
                if ((opts.method || '').toUpperCase() === 'POST' && opts.body) {
                    var rewritten = rewriteBatchBody(typeof opts.body === 'string' ? opts.body : null);
                    if (rewritten !== opts.body) {
                        newArgs[1] = Object.assign({}, opts, { body: rewritten });
                    }
                }
                return realFetch.apply(this, newArgs);
            }
        }

        return realFetch.apply(this, args);
    };

    var xhrKey = '__as' + Math.random().toString(36).substr(2, 4);

    XMLHttpRequest.prototype.open = function(method, url) {
        var async = arguments.length > 2 ? arguments[2] : true;
        var user = arguments[3];
        var password = arguments[4];

        if (typeof url === 'string') {
            this[xhrKey] = { url: url };
            if (isAuthApi(url)) this[xhrKey].modifyAuth = true;
            if (isPremiumApi(url)) this[xhrKey].modifyPremium = true;
            if (isThumbnailApi(url) && capturedRealUserId) url = rewriteUserId(url);
        }
        return realXHROpen.call(this, method, url, async, user, password);
    };

    XMLHttpRequest.prototype.send = function(body) {
        var flags = this[xhrKey];
        if (flags && isThumbnailApi(flags.url) && flags.url.includes('/batch') && body) {
            body = rewriteBatchBody(body);
        }
        return realXHRSend.call(this, body);
    };

    if (realResponseDesc) {
        Object.defineProperty(XMLHttpRequest.prototype, 'response', {
            get: function() {
                var flags = this[xhrKey];
                if (flags && this.readyState === 4) {
                    try {
                        var raw = realResponseDesc.get.call(this);
                        var data = typeof raw === 'string' ? JSON.parse(raw) : (typeof raw === 'object' ? raw : null);
                        if (data) {
                            if (flags.modifyAuth) {
                                if (!flags._mod) flags._mod = JSON.stringify(spoofAuthData(JSON.parse(JSON.stringify(data))));
                            } else if (flags.modifyPremium) {
                                if (!flags._mod) flags._mod = JSON.stringify(spoofPremiumFeatures(JSON.parse(JSON.stringify(data))));
                            }
                            if (flags._mod) return JSON.parse(flags._mod);
                        }
                    } catch(e) {}
                }
                return realResponseDesc.get.call(this);
            },
            configurable: true
        });
    }

    if (realResponseTextDesc) {
        Object.defineProperty(XMLHttpRequest.prototype, 'responseText', {
            get: function() {
                var flags = this[xhrKey];
                if (flags && this.readyState === 4) {
                    try {
                        var raw = realResponseTextDesc.get.call(this);
                        if (raw) {
                            if (flags.modifyAuth && !flags._mod) flags._mod = JSON.stringify(spoofAuthData(JSON.parse(raw)));
                            if (flags.modifyPremium && !flags._mod) flags._mod = JSON.stringify(spoofPremiumFeatures(JSON.parse(raw)));
                            if (flags._mod) return flags._mod;
                        }
                    } catch(e) {}
                }
                return realResponseTextDesc.get.call(this);
            },
            configurable: true
        });
    }
})();
