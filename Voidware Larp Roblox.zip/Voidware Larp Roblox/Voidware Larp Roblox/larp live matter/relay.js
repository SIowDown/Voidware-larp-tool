(function () {
  'use strict';

  const PENDING = {};

  function contextAlive() {
    try { return !!(chrome && chrome.runtime && chrome.runtime.id); } catch (e) { return false; }
  }

  /* ── MAIN World → Background Bridge ──────────────────────────── */
  function onRelayRequest(e) {
    if (!contextAlive()) {
      window.removeEventListener('bloxflare-relay-request', onRelayRequest);
      return;
    }
    const detail = e.detail;
    if (!detail || !detail.id || !detail.msg) return;
    try {
      chrome.runtime.sendMessage(detail.msg, function (response) {
        if (chrome.runtime.lastError) return; /* silently ignore */
        PENDING[detail.id] = response || { ok: false, error: 'No response' };
        window.dispatchEvent(new CustomEvent('bloxflare-relay-response', {
          detail: { id: detail.id, response: PENDING[detail.id] }
        }));
        delete PENDING[detail.id];
      });
    } catch (err) { /* context invalidated — ignore */ }
  }

  /* ── Extension URL Helper ─────────────────────────────────────── */
  function onGetUrl(e) {
    if (!contextAlive()) {
      window.removeEventListener('bloxflare-get-url', onGetUrl);
      return;
    }
    const detail = e.detail;
    if (!detail || !detail.id || !detail.path) return;
    try {
      const url = chrome.runtime.getURL(detail.path);
      window.dispatchEvent(new CustomEvent('bloxflare-url-response', {
        detail: { id: detail.id, url: url }
      }));
    } catch (err) { /* context invalidated — ignore */ }
  }

  window.addEventListener('bloxflare-relay-request', onRelayRequest);
  window.addEventListener('bloxflare-get-url', onGetUrl);

})();
