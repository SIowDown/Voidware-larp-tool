const http = require('http');
const fs   = require('fs');
const path = require('path');

const PORT             = 8765;
const DEFAULT_FILENAME = 'lawi.lua';
const ALLOWED_FILENAMES = [
  'lawi.lua', 'lawi_wear.lua', 'lawi_avatar.lua',
];

/* ── Helpers ──────────────────────────────────────────────────── */
function sendJson(res, status, data) {
  res.writeHead(status, {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'POST, GET, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
  });
  res.end(JSON.stringify(data));
}

function parseBody(req) {
  return new Promise(function (resolve, reject) {
    let body = '';
    req.on('data',  function (chunk) { body += chunk; });
    req.on('end',   function () {
      try { resolve(JSON.parse(body)); } catch (e) { reject(new Error('Invalid JSON')); }
    });
    req.on('error', reject);
  });
}

/* ── HTTP Server ──────────────────────────────────────────────── */
const server = http.createServer(async function (req, res) {
  if (req.method === 'OPTIONS') {
    res.writeHead(204, {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'POST, GET, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type',
    });
    res.end();
    return;
  }

  if (req.method === 'GET' && req.url === '/ping') {
    sendJson(res, 200, { status: 'ok', message: 'Lawi bridge is running' });
    return;
  }

  if (req.method === 'POST' && req.url === '/write-script') {
    try {
      const data = await parseBody(req);
      const { autoexecPath, script, filename } = data;

      if (!autoexecPath)
        return sendJson(res, 400, { status: 'error', message: 'No autoexec path provided' });
      if (!script)
        return sendJson(res, 400, { status: 'error', message: 'No script provided' });
      if (!fs.existsSync(autoexecPath))
        return sendJson(res, 400, { status: 'error', message: 'Path does not exist: ' + autoexecPath });
      if (!fs.statSync(autoexecPath).isDirectory())
        return sendJson(res, 400, { status: 'error', message: 'Path is not a directory' });

      const safeFile = ALLOWED_FILENAMES.includes(filename) ? filename : DEFAULT_FILENAME;
      const filePath = path.join(autoexecPath, safeFile);
      fs.writeFileSync(filePath, script, 'utf8');

      sendJson(res, 200, { status: 'ok', message: 'Script written', path: filePath });
    } catch (e) {
      sendJson(res, 500, { status: 'error', message: e.message });
    }
    return;
  }

  if (req.method === 'POST' && req.url === '/clear-script') {
    try {
      const data = await parseBody(req);
      const { autoexecPath, filename } = data;

      if (!autoexecPath)
        return sendJson(res, 400, { status: 'error', message: 'No autoexec path provided' });

      const safeFile = ALLOWED_FILENAMES.includes(filename) ? filename : DEFAULT_FILENAME;
      const filePath = path.join(autoexecPath, safeFile);
      if (fs.existsSync(filePath)) fs.unlinkSync(filePath);

      sendJson(res, 200, { status: 'ok', message: 'Script cleared' });
    } catch (e) {
      sendJson(res, 500, { status: 'error', message: e.message });
    }
    return;
  }

  sendJson(res, 404, { status: 'error', message: 'Not found' });
});

server.listen(PORT, '127.0.0.1', function () {
  console.log('\n  Lawi Bridge v1.0  —  http://localhost:' + PORT + '\n');
});

server.on('error', function (err) {
  if (err.code === 'EADDRINUSE') {
    console.error('Port ' + PORT + ' already in use. Is another bridge instance running?');
  } else {
    console.error('Server error:', err.message);
  }
  process.exit(1);
});
