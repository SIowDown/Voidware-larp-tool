(function () {
  'use strict';

  var AUTH_EVENT = 'voidware-auth-granted';
  var LS_KEY     = 'voidware_license';
  var LS_DATA_KEY        = 'voidware_license_data';
  var LS_KEY_LEGACY      = 'voidware_license_legacy';
  var LS_DATA_KEY_LEGACY = 'voidware_license_data_legacy';

  // Hardcoded valid keys (use VOID- prefix)
  var VALID_KEYS = [
    "VOID-SH1Q-7RYZ-HP6X",
    // add more keys as needed
  ];

  var AUTO_KEY = "VOID-SH1Q-7RYZ-HP6X";

  function writeLocalStorage(key, data) {
    try {
      var payload = JSON.stringify({
        valid:   true,
        key:     key,
        expires: data.expires || null,
        discord: data.discord || '',
        note:    data.note    || '',
      });
      localStorage.setItem(LS_KEY,             key);
      localStorage.setItem(LS_DATA_KEY,        payload);
      localStorage.setItem(LS_KEY_LEGACY,      key);
      localStorage.setItem(LS_DATA_KEY_LEGACY, payload);
    } catch (e) {}
  }

  function clearLocalStorage() {
    try {
      localStorage.removeItem(LS_KEY);
      localStorage.removeItem(LS_DATA_KEY);
      localStorage.removeItem(LS_KEY_LEGACY);
      localStorage.removeItem(LS_DATA_KEY_LEGACY);
    } catch (e) {}
  }

  function grantAuth(key, data) {
    writeLocalStorage(key, data);
    window.dispatchEvent(new CustomEvent(AUTH_EVENT, {
      detail: { key: key, data: data }
    }));
  }

  function checkStatus(cb, attempts) {
    // Always show overlay unless already valid locally
    cb('none', null);
  }

  function validateKey(key, cb) {
    var trimmed = key.trim();
    var found = VALID_KEYS.indexOf(trimmed) !== -1;
    if (found) {
      cb(true, null, { valid: true, expires: null, discord: '', note: '' });
    } else {
      cb(false, 'Invalid key. Please check and try again.');
    }
  }

  function clearAuth() {
    clearLocalStorage();
    try { chrome.runtime.sendMessage({ type: 'voidware-key-clear' }); } catch (e) {}
  }

  function buildOverlay() {
    if (document.getElementById('voidware-key-screen')) return;

    var el = document.createElement('div');
    el.id  = 'voidware-key-screen';
    document.body.appendChild(el);

    el.innerHTML =
      '<div class="lks-backdrop"></div>' +
      '<div class="lks-orb lks-orb-1"></div>' +
      '<div class="lks-orb lks-orb-2"></div>' +
      '<div class="lks-orb lks-orb-3"></div>' +
      '<div class="lks-border-wrap">' +
        '<div class="lks-card">' +
          '<div class="lks-inner-glow"></div>' +
          '<div class="lks-corner lks-corner-tl"></div>' +
          '<div class="lks-corner lks-corner-br"></div>' +
          '<div class="lks-logo-row">' +
            '<div class="lks-logo">' +
              '<span class="lks-logo-w">/voidware</span>' +
              '<span class="lks-logo-dot">.</span>' +
            '</div>' +
            '<div class="lks-badge"><span>Key Auth</span></div>' +
          '</div>' +
          '<div class="lks-heading">Enter your key</div>' +
          '<div class="lks-subheading">Paste or type your /voidware activation key below</div>' +
          '<div class="lks-field">' +
            '<div class="lks-field-icon">' +
              '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">' +
                '<circle cx="8" cy="15" r="4"/>' +
                '<path d="m11.5 11.5 7-7"/>' +
                '<path d="M16 4h4v4"/>' +
              '</svg>' +
            '</div>' +
            '<input id="lks-input" class="lks-input" type="text" placeholder="VOID-XXXX-XXXX-XXXX" autocomplete="off" spellcheck="false"/>' +
          '</div>' +
          '<div id="lks-err" class="lks-error"></div>' +
          '<button id="lks-btn" type="button" class="lks-btn">' +
            '<span id="lks-btn-lbl">Activate</span>' +
            '<div id="lks-spin" style="display:none;position:absolute;inset:0;display:none;align-items:center;justify-content:center;background:inherit;">' +
              '<div class="lks-spin-ring"></div>' +
            '</div>' +
          '</button>' +
          '<div class="lks-footer">' +
            'Need a key? <a href="https://discord.gg/voidware" target="_blank">Join the Discord</a>' +
          '</div>' +
        '</div>' +
      '</div>';

    var input    = el.querySelector('#lks-input');
    var errBox   = el.querySelector('#lks-err');
    var btn      = el.querySelector('#lks-btn');
    var btnLabel = el.querySelector('#lks-btn-lbl');
    var spinner  = el.querySelector('#lks-spin');

    if (input) {
      input.value = AUTO_KEY;
    }

    function showErr(msg) {
      errBox.textContent = msg;
      errBox.classList.toggle('lks-error-visible', !!msg);
    }
    function setLoading(on) {
      btn.disabled           = on;
      input.disabled         = on;
      btnLabel.style.display = on ? 'none' : '';
      spinner.style.display  = on ? 'flex'  : 'none';
    }

    function dismiss(delay) {
      setTimeout(function () {
        el.classList.add('lks-out');
        setTimeout(function () { if (el.parentNode) el.parentNode.removeChild(el); }, 300);
      }, delay || 0);
    }

    function showSuccess(data) {
      var wrap = el.querySelector('.lks-border-wrap');
      if (!wrap) return;
      var card = wrap.querySelector('.lks-card');
      if (!card) return;
      card.innerHTML =
        '<div class="lks-inner-glow"></div>' +
        '<div class="lks-success-wrap">' +
          '<div class="lks-check-ring">' +
            '<svg viewBox="0 0 52 52" fill="none">' +
              '<circle cx="26" cy="26" r="25" stroke="url(#cg)" stroke-width="2"/>' +
              '<polyline points="14,27 22,35 38,18" stroke="url(#cg)" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>' +
              '<defs><linearGradient id="cg" x1="0" y1="0" x2="52" y2="52" gradientUnits="userSpaceOnUse">' +
                '<stop offset="0%" stop-color="#818cf8"/>' +
                '<stop offset="100%" stop-color="#e879f9"/>' +
              '</linearGradient></defs>' +
            '</svg>' +
          '</div>' +
          '<div class="lks-success-title">Activated!</div>' +
          '<div class="lks-success-sub">Welcome to /voidware. Loading\u2026</div>' +
        '</div>';
    }

    function onActivate() {
      var raw = input.value.trim();
      if (!raw) { showErr('Please enter your key.'); input.focus(); return; }
      showErr('');
      setLoading(true);
      clearAuth();
      validateKey(raw, function (ok, errMsg, data) {
        setLoading(false);
        if (ok) {
          showSuccess(data);
          grantAuth(raw, data || {});
          dismiss(1400);
        } else {
          showErr(errMsg || 'Invalid key. Please check and try again.');
          input.focus();
        }
      });
    }

    btn.addEventListener('click', onActivate);
    input.addEventListener('keydown', function (e) { if (e.key === 'Enter') onActivate(); });

    input.addEventListener('input', function () {
      var cur = input.selectionStart;
      var raw = input.value.toUpperCase().replace(/[^A-Z0-9]/g, '');
      if (raw.startsWith('VOID')) raw = raw.slice(4);
      var seg = [raw.slice(0, 4), raw.slice(4, 8), raw.slice(8, 12)].filter(Boolean);
      var formatted = 'VOID-' + seg.join('-');
      if (input.value !== formatted) {
        input.value = formatted;
        try { input.setSelectionRange(cur + 1, cur + 1); } catch (e) {}
      }
    });

    setTimeout(function () { input.focus(); }, 80);
  }

  function isLocallyValid() {
    try {
      var raw = localStorage.getItem(LS_DATA_KEY);
      if (!raw) return false;
      var d = JSON.parse(raw);
      if (!d || !d.valid) return false;
      if (d.expires && d.expires < Date.now()) return false;
      return d;
    } catch (e) { return false; }
  }

  function boot() {
    var local = isLocallyValid();
    if (local) {
      grantAuth(local.key || '', local);
      return;
    }
    checkStatus(function (state, data) {
      if (state === 'valid') { grantAuth(data.key || '', data); return; }
      buildOverlay();
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }
})();