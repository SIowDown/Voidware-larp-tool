/* lawi — UI v3 "Blade"
   Snow  ·  Header  ·  Underline tabs  ·  Columns  ·  Footer  ·  Alt+L toggle
   + Credits tab added
*/
(function () {
  'use strict';

  var PANEL_KEY = 'lawi_panel_off';
  var POS_X_KEY = 'lawi_ui_x';
  var POS_Y_KEY = 'lawi_ui_y';

  /* ── Primed state — set by clicking the extension icon ──────── */
  var isPrimed = false;

  function fetchPrimedState(cb) {
    try {
      chrome.runtime.sendMessage({ type: 'lawi-get-primed' }, function (resp) {
        if (chrome.runtime.lastError) { cb(false); return; }
        cb(!!(resp && resp.primed));
      });
    } catch (e) { cb(false); }
  }

  try {
    chrome.runtime.onMessage.addListener(function (msg) {
      if (msg.type !== 'lawi-primed-changed') return;
      isPrimed = !!msg.primed;
    });
  } catch (e) {}

  /* ── Cookie helper ─────────────────────────────────────────── */
  function getCookie(name) {
    var m = document.cookie.match(new RegExp('(?:^|;\\s*)' + name.replace(/[\^$.*+?()[\]{}|]/g, '\\$&') + '=([^;]*)'));
    return m ? decodeURIComponent(m[1]) : '';
  }

  /* ── Avatar thumbnail (right panel) ───────────────────────── */
  function loadAvatarThumb() {
    var uid   = getCookie('__blf_uid') || getCookie('__blf_ruid');
    var uname = getCookie('__blf_uname');
    var frame = document.getElementById('lawi-avatar-frame');
    var uEl   = document.getElementById('lawi-avatar-username');
    var iEl   = document.getElementById('lawi-avatar-id');

    if (uname && uEl) uEl.textContent = uname;
    if (uid   && iEl) iEl.textContent = 'ID: ' + uid;

    if (!frame) return;

    frame.innerHTML = '<div class="lawi-avatar-placeholder">Loading avatar…</div>';

    if (!uid) {
      fetch('https://users.roblox.com/v1/users/authenticated', { credentials: 'include' })
        .then(function (r) { return r.json(); })
        .then(function (j) {
          if (j && j.id) {
            if (iEl) iEl.textContent = 'ID: ' + j.id;
            if (uEl && j.name) uEl.textContent = j.name;
            fetchHeadshot(j.id, frame);
          } else {
            frame.innerHTML = '';
          }
        })
        .catch(function () { frame.innerHTML = ''; });
      return;
    }

    fetchHeadshot(uid, frame);
  }

  function fetchHeadshot(uid, frame) {
    fetch('https://thumbnails.roblox.com/v1/users/avatar-headshot?userIds=' + uid + '&size=420x420&format=Png', { credentials: 'include' })
      .then(function (r) { return r.json(); })
      .then(function (json) {
        var d = json && json.data && json.data[0];
        if (!d || !d.imageUrl) { frame.innerHTML = ''; return; }
        var img = document.createElement('img');
        img.src = d.imageUrl;
        frame.innerHTML = '';
        frame.appendChild(img);
      })
      .catch(function () { frame.innerHTML = ''; });
  }

  /* ── Asset thumbnail via thumbnails.roblox.com API ──────────── */
  var _thumbQueue   = [];
  var _thumbPending = false;

  function flushThumbQueue() {
    if (_thumbPending || !_thumbQueue.length) return;
    var batch = _thumbQueue.splice(0, 10);
    _thumbPending = true;
    var ids = batch.map(function (b) { return b.id; }).join(',');
    fetch('https://thumbnails.roblox.com/v1/assets?assetIds=' + ids + '&size=150x150&format=Png', { credentials: 'include' })
      .then(function (r) { return r.json(); })
      .then(function (json) {
        var data = json && json.data || [];
        data.forEach(function (d) {
          batch.forEach(function (b) {
            if (String(b.id) === String(d.targetId) && d.imageUrl) {
              b.img.src = d.imageUrl;
            }
          });
        });
      })
      .catch(function () {})
      .then(function () {
        _thumbPending = false;
        if (_thumbQueue.length) setTimeout(flushThumbQueue, 80);
      });
  }

  function queueThumb(assetId, imgEl) {
    _thumbQueue.push({ id: assetId, img: imgEl });
    if (!_thumbPending) setTimeout(flushThumbQueue, 50);
  }

  var GREY_PLACEHOLDER = 'data:image/svg+xml,%3Csvg xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22 width%3D%2238%22 height%3D%2238%22%3E%3Crect width%3D%2238%22 height%3D%2238%22 rx%3D%226%22 fill%3D%22%231a1a22%22%2F%3E%3C%2Fsvg%3E';

  function extractAssetId(text) {
    var m = String(text || '').match(/\d{5,}/);
    return m ? m[0] : '';
  }

  function addItemThumb(ctrl) {
    if (ctrl.dataset.thumbAdded) return;
    ctrl.dataset.thumbAdded = '1';

    var nameEl   = ctrl.querySelector('.name');
    var inputEl  = ctrl.querySelector('input');
    var selectEl = ctrl.querySelector('select');

    var nameText = (nameEl   ? nameEl.textContent  : '').trim();
    var inputVal = (inputEl  ? inputEl.value        : '').trim();
    var selVal   = (selectEl ? selectEl.value       : '').trim();

    var assetId = extractAssetId(nameText) || extractAssetId(inputVal) || extractAssetId(selVal);
    if (!assetId) return;

    var wrap = document.createElement('span');
    wrap.className = 'lawi-thumb-wrap';

    var img = document.createElement('img');
    img.className = 'lawi-item-thumb';
    img.alt = '';
    img.src = GREY_PLACEHOLDER;

    queueThumb(assetId, img);

    wrap.appendChild(img);
    ctrl.appendChild(wrap);
    ctrl.classList.add('lawi-has-thumb');
  }

  function addThumbsToSection(root) {
    requestAnimationFrame(function () {
      root.querySelectorAll('.controller').forEach(addItemThumb);
    });
  }

  /* ── Google Fonts ──────────────────────────────────────────── */
  function injectFonts() {
    if (document.getElementById('lawi-fonts')) return;
    var link = document.createElement('link');
    link.id   = 'lawi-fonts';
    link.rel  = 'stylesheet';
    link.href = 'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap';
    document.head.appendChild(link);
  }

  /* ── Snow overlay ──────────────────────────────────────────── */
  function createOverlay() {
    if (document.getElementById('lawi-overlay')) return;

    var ov = document.createElement('div');
    ov.id  = 'lawi-overlay';

    var symbols = ['•', '◦', '·'];
    for (var i = 0; i < 18; i++) {
      var f = document.createElement('span');
      f.className = 'lawi-flake';
      f.textContent = symbols[i % symbols.length];
      var size = 5 + Math.random() * 5;
      var dur = 10 + Math.random() * 8;
      var delay = -(Math.random() * 12);
      var left = Math.random() * 100;
      f.style.cssText =
        'font-size:' + size.toFixed(1) + 'px;' +
        'left:' + left.toFixed(1) + '%;' +
        'animation-duration:' + dur.toFixed(1) + 's;' +
        'animation-delay:' + delay.toFixed(1) + 's;' +
        'top:-20px;';
      ov.appendChild(f);
    }

    try {
      if (localStorage.getItem(PANEL_KEY) === '1') ov.classList.add('lawi-hidden');
    } catch (e) {}

    document.documentElement.appendChild(ov);
  }

  /* ── Helpers ───────────────────────────────────────────────── */
  function getFolderLabel(folder) {
    var t = folder.querySelector(':scope > .title');
    return t ? (t.textContent || '').replace(/\s*[▾▸]\s*$/, '').trim() : '—';
  }

  function openFolder(folder) {
    if (!folder) return;
    folder.classList.remove('closed');
    var t  = folder.querySelector(':scope > .title');
    var ch = folder.querySelector(':scope > .children');
    if (t)  t.setAttribute('aria-expanded', 'true');
    if (ch) { ch.style.height = ''; ch.style.overflow = ''; ch.style.opacity = ''; }
  }

  function isInventoryLike(subs) {
    for (var i = 0; i < subs.length; i++) {
      var l = getFolderLabel(subs[i]).toLowerCase();
      if (l.indexOf('item') !== -1 || l.indexOf('gamepass') !== -1 || l.indexOf('owned') !== -1) return true;
    }
    return false;
  }

  function isWearLike(label) {
    var l = label.toLowerCase();
    return l.indexOf('wear') !== -1 || l.indexOf('avatar') !== -1 || l.indexOf('equip') !== -1;
  }

  /* ── Inventory accordion layout ─────────────────────────────── */
  function buildInventoryLayout(folder, fc, subs) {
    subs.sort(function (a, b) {
      function rank(l) {
        l = l.toLowerCase();
        if (l.indexOf('item') !== -1)     return 0;
        if (l.indexOf('gamepass') !== -1 || l.indexOf('pass') !== -1) return 2;
        return 1;
      }
      return rank(getFolderLabel(a)) - rank(getFolderLabel(b));
    });

    var directCtrls = Array.from(fc.querySelectorAll(':scope > .controller'));

    while (fc.firstChild) fc.removeChild(fc.firstChild);

    if (directCtrls.length) {
      var strip = document.createElement('div');
      strip.className = 'lawi-direct-ctrls';
      directCtrls.forEach(function (c) { strip.appendChild(c); });
      fc.appendChild(strip);
    }

    var wrapper = document.createElement('div');
    wrapper.className = 'lawi-inv-wrapper';

    subs.forEach(function (sf, idx) {
      var label   = getFolderLabel(sf);

      var sfChildren = sf.querySelector(':scope > .children');
      var ctrlCount  = sfChildren ? sfChildren.querySelectorAll('.controller').length : 0;

      var section = document.createElement('div');
      section.className = 'lawi-inv-section' + (idx === 0 ? ' lawi-inv-open' : '');

      var toggle = document.createElement('button');
      toggle.type = 'button';
      toggle.className = 'lawi-inv-toggle';
      toggle.innerHTML =
        '<span class="lawi-inv-chevron">▶</span>' +
        label +
        '<span class="lawi-inv-count">' + ctrlCount + '</span>';
      toggle.addEventListener('click', function () {
        section.classList.toggle('lawi-inv-open');
      });

      var body = document.createElement('div');
      body.className = 'lawi-inv-body';

      if (sfChildren) {
        body.appendChild(sfChildren);
        addThumbsToSection(body);
      }

      section.appendChild(toggle);
      section.appendChild(body);
      wrapper.appendChild(section);
    });

    fc.appendChild(wrapper);
  }

  /* ── Build column groups for one main-tab folder ────────────── */
  function buildColumns(folder) {
    if (!folder || folder.dataset.colBuilt) return;
    folder.dataset.colBuilt = '1';

    openFolder(folder);

    var fc = folder.querySelector(':scope > .children');
    if (!fc) return;

    var subs = Array.from(fc.querySelectorAll(':scope > .lil-gui'));
    var topLabel = getFolderLabel(folder);

    if (!subs.length) {
      folder.classList.add('lawi-flat');
      if (isWearLike(topLabel)) addThumbsToSection(fc);
      return;
    }

    if (isInventoryLike(subs)) {
      buildInventoryLayout(folder, fc, subs);
      return;
    }

    if (isWearLike(topLabel)) {
      subs.forEach(function (sf) { addThumbsToSection(sf); });
    }

    if (subs.length === 1) {
      openFolder(subs[0]);
      subs[0].querySelectorAll('.lil-gui').forEach(openFolder);
      subs[0].classList.add('lawi-sub-active', 'lawi-solo');
      return;
    }

    var directCtrls = Array.from(fc.querySelectorAll(':scope > .controller'));
    var mid    = Math.ceil(subs.length / 2);
    var groups = [subs.slice(0, mid), subs.slice(mid)];

    var colWrapper = document.createElement('div');
    colWrapper.className = 'lawi-col-wrapper';

    groups.forEach(function (group) {
      if (!group.length) return;

      var col = document.createElement('div');
      col.className = 'lawi-col';

      var tabWrap = document.createElement('div');
      tabWrap.className = 'lawi-col-tabwrap';

      var btnLeft = document.createElement('button');
      btnLeft.type = 'button';
      btnLeft.className = 'lawi-col-arrow lawi-col-arrow-l';
      btnLeft.innerHTML = '‹';
      btnLeft.setAttribute('aria-label', 'Scroll tabs left');

      var tabBar = document.createElement('div');
      tabBar.className = 'lawi-col-tabs';

      var btnRight = document.createElement('button');
      btnRight.type = 'button';
      btnRight.className = 'lawi-col-arrow lawi-col-arrow-r';
      btnRight.innerHTML = '›';
      btnRight.setAttribute('aria-label', 'Scroll tabs right');

      tabWrap.appendChild(btnLeft);
      tabWrap.appendChild(tabBar);
      tabWrap.appendChild(btnRight);

      btnLeft.addEventListener('click',  function () { tabBar.scrollBy({ left: -120, behavior: 'smooth' }); });
      btnRight.addEventListener('click', function () { tabBar.scrollBy({ left:  120, behavior: 'smooth' }); });

      function refreshArrows() {
        var canLeft  = tabBar.scrollLeft > 2;
        var canRight = tabBar.scrollLeft + tabBar.clientWidth < tabBar.scrollWidth - 2;
        btnLeft.style.opacity  = canLeft  ? '1' : '0.25';
        btnRight.style.opacity = canRight ? '1' : '0.25';
        btnLeft.style.pointerEvents  = canLeft  ? '' : 'none';
        btnRight.style.pointerEvents = canRight ? '' : 'none';
      }
      tabBar.addEventListener('scroll', refreshArrows);
      setTimeout(refreshArrows, 60);

      var content = document.createElement('div');
      content.className = 'lawi-col-content';

      group.forEach(function (sf, idx) {
        openFolder(sf);
        sf.querySelectorAll('.lil-gui').forEach(openFolder);

        var label = getFolderLabel(sf);
        var savedTab = '';
        try { savedTab = localStorage.getItem('lawi_tab_' + getFolderLabel(folder)) || ''; } catch (e) {}
        var isFirstActive = savedTab ? label === savedTab : idx === 0;

        var btn   = document.createElement('button');
        btn.type  = 'button';
        btn.className = 'lawi-col-tab' + (isFirstActive ? ' lawi-col-tab-active' : '');
        btn.textContent = label;

        if (isFirstActive) sf.classList.add('lawi-sub-active');

        btn.addEventListener('click', function () {
          tabBar.querySelectorAll('.lawi-col-tab').forEach(function (t) {
            t.classList.remove('lawi-col-tab-active');
          });
          group.forEach(function (f) { f.classList.remove('lawi-sub-active'); });
          btn.classList.add('lawi-col-tab-active');
          sf.classList.add('lawi-sub-active');
          btn.scrollIntoView({ block: 'nearest', inline: 'nearest' });
          setTimeout(refreshArrows, 80);
          try { localStorage.setItem('lawi_tab_' + getFolderLabel(folder), label); } catch (e) {}
        });

        tabBar.appendChild(btn);
        content.appendChild(sf);
      });

      col.appendChild(tabWrap);
      col.appendChild(content);
      colWrapper.appendChild(col);
    });

    while (fc.firstChild) fc.removeChild(fc.firstChild);

    if (directCtrls.length) {
      var strip = document.createElement('div');
      strip.className = 'lawi-direct-ctrls';
      directCtrls.forEach(function (c) { strip.appendChild(c); });
      fc.appendChild(strip);
    }

    fc.appendChild(colWrapper);
  }

  /* ── Nav icons — mapped by lowercase folder label ───────────── */
  var NAV_ICONS = {
    'profile': '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="8" r="4"/><path d="M4 20c0-4 3.6-7 8-7s8 3 8 7"/></svg>',
    'currency': '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M9.5 9h3.5a2 2 0 0 1 0 4H9.5V9z"/><path d="M9.5 9v7"/><path d="M13 13l2.5 3"/></svg>',
    'inventory': '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"/><line x1="3" y1="6" x2="21" y2="6"/><path d="M16 10a4 4 0 0 1-8 0"/></svg>',
    'wear': '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M20.38 3.46 16 2a4 4 0 0 1-8 0L3.62 3.46a2 2 0 0 0-1.34 2.23l.58 3.57a1 1 0 0 0 .99.84H6v10c0 1.1.9 2 2 2h8a2 2 0 0 0 2-2V10h2.15a1 1 0 0 0 .99-.84l.58-3.57a2 2 0 0 0-1.34-2.23z"/></svg>',
    'avatar': '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="8" r="4"/><path d="M4 20c0-4 3.6-7 8-7s8 3 8 7"/><path d="M17.5 3.5 19 5l-1.5 1.5"/><path d="M19 3.5 17.5 5l1.5 1.5"/></svg>',
    'identity': '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="9" cy="8" r="4"/><path d="M3 20c0-4 2.7-7 7-7"/><circle cx="18" cy="16" r="4"/><path d="M18 13.5v2.2"/><circle cx="18" cy="17.5" r=".6" fill="currentColor" stroke="none"/></svg>',
    'trades': '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M7 16V4m0 0-3 4m3-4 3 4"/><path d="M17 8v12m0 0 3-4m-3 4-3-4"/></svg>',
    'wipe': '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6"/><path d="M14 11v6"/><path d="M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"/></svg>',
  };

  function getNavIcon(label) {
    var key = label.toLowerCase().trim();
    return NAV_ICONS[key] || '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/></svg>';
  }

  var HIDDEN_TABS = ['license'];

  /* ── Glass 3-panel shell (left nav | center content | right avatar) ── */
  function buildGlassShell(root) {
    if (root.querySelector('#lawi-glass-shell')) return;

    var rootChildren = root.querySelector(':scope > .children');
    if (!rootChildren) return;

    var topFolders = Array.from(rootChildren.querySelectorAll(':scope > .lil-gui'))
      .filter(function (f) {
        var lbl = getFolderLabel(f).toLowerCase();
        return !HIDDEN_TABS.some(function (h) { return lbl.indexOf(h) !== -1; });
      });
    if (!topFolders.length) return;

    topFolders.forEach(openFolder);

    var shell = document.createElement('div');
    shell.id = 'lawi-glass-shell';

    var left = document.createElement('div');
    left.id = 'lawi-left';
    left.innerHTML =
      '<div class="lawi-brand-block" id="lawi-drag-handle" title="Drag to move">' +
        '<div class="lawi-brand-name">/voidware</div>' +
        '<div class="lawi-brand-tagline">v1.2</div>' +
      '</div>' +
      '<nav class="lawi-nav" id="lawi-nav" aria-label="Sections"></nav>' +
      '<div class="lawi-left-footer">' +
        '<div class="lawi-keybind-hint" title="Press Alt+L to toggle the GUI">' +
          '<span class="lawi-kb-key">ALT</span>' +
          '<span class="lawi-kb-sep">+</span>' +
          '<span class="lawi-kb-key">L</span>' +
        '</div>' +
      '</div>';

    var center = document.createElement('div');
    center.id = 'lawi-center';

    var right = document.createElement('div');
    right.id = 'lawi-right';
    right.innerHTML =
      '<div class="lawi-avatar-header">' +
        '<span class="lawi-avatar-title">avatar</span>' +
      '</div>' +
      '<div class="lawi-avatar-frame" id="lawi-avatar-frame"></div>' +
      '<div class="lawi-avatar-user">' +
        '<span class="lawi-avatar-username" id="lawi-avatar-username">—</span>' +
        '<span class="lawi-avatar-id" id="lawi-avatar-id"></span>' +
      '</div>' +
      '<div class="lawi-right-toggles">' +
        '<div class="lawi-right-toggle-row" id="lawi-badge-row">' +
          '<label class="lawi-rtoggle-label" for="lawi-badge-cb">✓ Verified Badge</label>' +
          '<input type="checkbox" class="lawi-rtoggle-cb" id="lawi-badge-cb">' +
        '</div>' +
        '<div class="lawi-right-toggle-row" id="lawi-premium-row">' +
          '<label class="lawi-rtoggle-label" for="lawi-premium-cb">★ Roblox Premium</label>' +
          '<input type="checkbox" class="lawi-rtoggle-cb" id="lawi-premium-cb">' +
        '</div>' +
      '</div>';

    /* Shared fixed tooltip — lives on body, outside overflow:hidden */
    var navTip = document.getElementById('lawi-nav-tip');
    if (!navTip) {
      navTip = document.createElement('div');
      navTip.id = 'lawi-nav-tip';
      document.body.appendChild(navTip);
    }

    var nav = left.querySelector('#lawi-nav');
    var lastNavIdx = 0;
    try { lastNavIdx = parseInt(localStorage.getItem('lawi_nav_idx') || '0', 10) || 0; } catch (e) {}
    if (lastNavIdx >= topFolders.length) lastNavIdx = 0;

    topFolders.forEach(function (folder, idx) {
      var label = getFolderLabel(folder);
      var btn = document.createElement('button');
      btn.type = 'button';
      var isActive = idx === lastNavIdx;
      btn.className = 'lawi-nav-btn' + (isActive ? ' lawi-nav-btn-active' : '');
      var badge = document.createElement('span');
      badge.className = 'lawi-nav-badge';
      badge.style.display = 'none';
      btn.innerHTML = '<span class="lawi-nav-icon">' + getNavIcon(label) + '</span>';
      btn.appendChild(badge);
      btn.addEventListener('mouseenter', function () {
        var r = btn.getBoundingClientRect();
        navTip.textContent = label;
        navTip.style.top     = (r.top + r.height / 2) + 'px';
        navTip.style.left    = (r.right + 14) + 'px';
        navTip.style.opacity = '1';
      });
      btn.addEventListener('mouseleave', function () { navTip.style.opacity = '0'; });
      btn.addEventListener('click', function () {
        left.querySelectorAll('.lawi-nav-btn').forEach(function (t) { t.classList.remove('lawi-nav-btn-active'); });
        topFolders.forEach(function (f) { f.classList.remove('lawi-active'); });
        btn.classList.add('lawi-nav-btn-active');
        folder.classList.add('lawi-active');
        buildColumns(folder);
        // Hide credits panel if visible
        var creditsPanel = center.querySelector('#lawi-credits-panel');
        if (creditsPanel) creditsPanel.style.display = 'none';
        try { localStorage.setItem('lawi_nav_idx', idx); } catch (e) {}
      });
      nav.appendChild(btn);
      setTimeout(function () { setupNavBadge(folder, badge); }, 300);
      if (isActive) { folder.classList.add('lawi-active'); buildColumns(folder); }
    });

    // ============ ADD CREDITS BUTTON ============
    var creditsBtn = document.createElement('button');
    creditsBtn.type = 'button';
    creditsBtn.className = 'lawi-nav-btn';
    creditsBtn.innerHTML = '<span class="lawi-nav-icon"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M12 8v4l3 3M12 22a10 10 0 1 0 0-20 10 10 0 0 0 0 20z"/><path d="M12 6v2"/></svg></span>';
    creditsBtn.setAttribute('data-custom-tab', 'credits');
    creditsBtn.addEventListener('mouseenter', function () {
      var r = creditsBtn.getBoundingClientRect();
      navTip.textContent = 'Credits';
      navTip.style.top = (r.top + r.height / 2) + 'px';
      navTip.style.left = (r.right + 14) + 'px';
      navTip.style.opacity = '1';
    });
    creditsBtn.addEventListener('mouseleave', function () { navTip.style.opacity = '0'; });
    creditsBtn.addEventListener('click', function () {
      left.querySelectorAll('.lawi-nav-btn').forEach(function (t) { t.classList.remove('lawi-nav-btn-active'); });
      creditsBtn.classList.add('lawi-nav-btn-active');
      topFolders.forEach(function (f) { f.classList.remove('lawi-active'); });
      showCreditsContent(center);
    });
    nav.appendChild(creditsBtn);
    // ============================================

    /* Search bar */
    var searchWrap = document.createElement('div');
    searchWrap.className = 'lawi-search-wrap';
    var searchInput = document.createElement('input');
    searchInput.type = 'text';
    searchInput.className = 'lawi-search-input';
    searchInput.placeholder = 'Search controls...';
    searchWrap.appendChild(searchInput);
    center.appendChild(searchWrap);

    searchInput.addEventListener('input', function () {
      var q = searchInput.value.toLowerCase().trim();

      if (!q) {
        center.querySelectorAll('.controller').forEach(function (c) { c.style.display = ''; });
        center.querySelectorAll('.lil-gui').forEach(function (f) { f.style.display = ''; });
        /* restore original name text */
        center.querySelectorAll('.controller > .name[data-orig]').forEach(function (n) {
          n.textContent = n.dataset.orig; delete n.dataset.orig;
        });
        return;
      }

      center.querySelectorAll('.lil-gui').forEach(function (f) { f.style.display = 'block'; });

      center.querySelectorAll('.controller').forEach(function (ctrl) {
        var nameEl = ctrl.querySelector('.name');
        var orig   = nameEl ? (nameEl.dataset.orig || nameEl.textContent) : '';
        var text   = orig.toLowerCase();
        var match  = text.indexOf(q) !== -1;
        ctrl.style.display = match ? '' : 'none';
        if (nameEl && match) {
          if (!nameEl.dataset.orig) nameEl.dataset.orig = orig;
          var i = text.indexOf(q);
          nameEl.innerHTML = escHtml(orig.slice(0, i)) +
            '<mark class="lawi-match">' + escHtml(orig.slice(i, i + q.length)) + '</mark>' +
            escHtml(orig.slice(i + q.length));
        } else if (nameEl && nameEl.dataset.orig) {
          nameEl.textContent = nameEl.dataset.orig;
          delete nameEl.dataset.orig;
        }
      });
    });

    center.appendChild(rootChildren);
    shell.appendChild(left);
    shell.appendChild(center);
    shell.appendChild(right);

    /* ── Verified badge toggle wiring ─────────────────────────── */
    var badgeCb = right.querySelector('#lawi-badge-cb');
    if (badgeCb) {
      try {
        badgeCb.checked = localStorage.getItem('lawi_verified_toggle') === '1';
      } catch (e) {}
      badgeCb.addEventListener('change', function () {
        try {
          localStorage.setItem('lawi_verified_toggle', badgeCb.checked ? '1' : '0');
        } catch (e) {}
        showToast('Verified Badge: ' + (badgeCb.checked ? 'ON' : 'OFF') + ' — reloading...', badgeCb.checked ? 'on' : 'off');
        setTimeout(function () { location.reload(); }, 900);
      });
    }

    /* ── Premium toggle wiring ─────────────────────────────────── */
    var premiumCb = right.querySelector('#lawi-premium-cb');
    if (premiumCb) {
      try {
        premiumCb.checked = localStorage.getItem('lawi_premium_toggle') === '1';
      } catch (e) {}
      premiumCb.addEventListener('change', function () {
        try {
          localStorage.setItem('lawi_premium_toggle', premiumCb.checked ? '1' : '0');
        } catch (e) {}
        showToast('Roblox Premium: ' + (premiumCb.checked ? 'ON' : 'OFF') + ' — reloading...', premiumCb.checked ? 'on' : 'off');
        setTimeout(function () { location.reload(); }, 900);
      });
    }

    var oldHeader = root.querySelector('#lawi-header');
    var oldTabs = root.querySelector('#lawi-main-tabs');
    var oldFooter = root.querySelector('#lawi-footer');
    if (oldHeader) root.removeChild(oldHeader);
    if (oldTabs) root.removeChild(oldTabs);
    if (oldFooter) root.removeChild(oldFooter);
    root.appendChild(shell);

    applySavedPosition(root);
    setupDrag(root);

    /* Show the blur backdrop now that the GUI is live (unless panel is stored as hidden) */
    var bd = document.getElementById('lawi-blur-backdrop');
    if (bd) {
      try {
        if (localStorage.getItem(PANEL_KEY) !== '1') {
          bd.classList.remove('lawi-hidden');
        }
      } catch (e) { bd.classList.remove('lawi-hidden'); }
    }

    /* Minimize button */
    var minBtn = document.createElement('button');
    minBtn.id = 'lawi-min-btn';
    minBtn.title = 'Minimize';
    minBtn.textContent = '—';
    minBtn.addEventListener('click', function () {
      var minimized = shell.classList.toggle('lawi-minimized');
      minBtn.title = minimized ? 'Restore' : 'Minimize';
      minBtn.textContent = minimized ? '▸' : '—';
    });
    shell.appendChild(minBtn);

    /* Status bar */
    createStatusBar(center, root);

    setTimeout(function () { createRainCanvas(shell); }, 60);
    setTimeout(loadAvatarThumb, 400);
    setTimeout(function () { createWelcomeModal(); }, 700);

    setTimeout(function () { setupAutoHide(shell); }, 500);
    setTimeout(function () { setupContextMenu(root); }, 400);
  }

  // ── Credits Content Function ─────────────────────────────────
  function showCreditsContent(center) {
    if (!center) return;
    // Hide all normal GUI folders
    center.querySelectorAll('.lil-gui').forEach(function (el) {
      el.style.display = 'none';
    });
    // Remove existing credits panel if any, to refresh
    var oldCredits = center.querySelector('#lawi-credits-panel');
    if (oldCredits) oldCredits.remove();
    // Create new credits panel
    var creditsDiv = document.createElement('div');
    creditsDiv.id = 'lawi-credits-panel';
    creditsDiv.className = 'lawi-credits-content';
    creditsDiv.innerHTML = `
      <div style="display:flex; flex-direction:column; align-items:center; justify-content:center; height:100%; text-align:center; padding:40px;">
        <h2 style="color: #00e040; margin-bottom: 20px;">✨ Credits ✨</h2>
        <p style="font-size: 16px; font-weight: 500;">Cracked By <strong style="color:#00e040;">Syninject/Ocularr</strong></p>
        <p style="margin-top: 20px; font-size: 12px; color: #888;">Thanks for using /voidware</p>
      </div>
    `;
    // Insert after search bar (if exists)
    var searchWrap = center.querySelector('.lawi-search-wrap');
    if (searchWrap && searchWrap.nextSibling) {
      center.insertBefore(creditsDiv, searchWrap.nextSibling);
    } else {
      center.appendChild(creditsDiv);
    }
    creditsDiv.style.display = 'block';
  }

  function applySavedPosition(root) {
    try {
      var x = localStorage.getItem(POS_X_KEY);
      var y = localStorage.getItem(POS_Y_KEY);
      if (x != null && y != null) {
        var nx = parseInt(x, 10);
        var ny = parseInt(y, 10);
        if (!isNaN(nx) && !isNaN(ny)) {
          root.style.setProperty('left', nx + 'px', 'important');
          root.style.setProperty('top', ny + 'px', 'important');
          root.style.setProperty('transform', 'none', 'important');
        }
      }
    } catch (e) {}
  }

  function setupDrag(root) {
    var handle = document.getElementById('lawi-drag-handle');
    if (!handle) return;

    var dragging = false;
    var startX = 0, startY = 0, startLeft = 0, startTop = 0;

    function onDown(e) {
      if (e.button !== 0) return;
      dragging = true;
      var r = root.getBoundingClientRect();
      startLeft = r.left;
      startTop = r.top;
      startX = e.clientX;
      startY = e.clientY;
      root.style.setProperty('left', startLeft + 'px', 'important');
      root.style.setProperty('top', startTop + 'px', 'important');
      root.style.setProperty('transform', 'none', 'important');
      document.addEventListener('mousemove', onMove);
      document.addEventListener('mouseup', onUp);
      e.preventDefault();
    }

    function onMove(e) {
      if (!dragging) return;
      var dx = e.clientX - startX;
      var dy = e.clientY - startY;
      var left = Math.max(0, startLeft + dx);
      var top = Math.max(0, startTop + dy);
      root.style.setProperty('left', left + 'px', 'important');
      root.style.setProperty('top', top + 'px', 'important');
      e.preventDefault();
    }

    function onUp() {
      if (!dragging) return;
      dragging = false;
      document.removeEventListener('mousemove', onMove);
      document.removeEventListener('mouseup', onUp);
      try {
        var r = root.getBoundingClientRect();
        localStorage.setItem(POS_X_KEY, Math.round(r.left).toString());
        localStorage.setItem(POS_Y_KEY, Math.round(r.top).toString());
      } catch (e) {}
    }

    handle.addEventListener('mousedown', onDown);
  }

  /* ── Restore saved visibility state ────────────────────────── */
  function hideIfStored(node) {
    try {
      if (localStorage.getItem(PANEL_KEY) === '1') {
        node.classList.add('lawi-hidden');
        node.style.setProperty('display', 'none', 'important');
      }
    } catch (e) {}
  }

  function setupGui(root) {
    if (root.dataset.lawiInit) return;
    root.dataset.lawiInit = '1';
    root.classList.add('lawi-panel-visible');

    buildGlassShell(root);
    root.querySelectorAll('.lil-gui').forEach(openFolder);
    setupCheckboxToasts(root);
  }

  var obsScheduled = false;
  function scheduleSetup(node) {
    if (node.dataset.lawiInit) return;
    if (obsScheduled) return;
    obsScheduled = true;
    requestAnimationFrame(function () {
      obsScheduled = false;
      if (node.dataset.lawiInit) return;
      hideIfStored(node);
      createOverlay();
      setupGui(node);
    });
  }

  /* ── Page blur backdrop — created hidden, shown only when GUI opens ── */
  function createBlurBackdrop() {
    if (document.getElementById('lawi-blur-backdrop')) return;
    var el = document.createElement('div');
    el.id = 'lawi-blur-backdrop';
    el.classList.add('lawi-hidden'); /* stays hidden until buildGlassShell reveals it */
    document.body.appendChild(el);
  }

  /* ── Background canvas — rain or ZZZ clouds ─────────────────── */
  function createRainCanvas(shell) {
    if (shell.querySelector('#lawi-rain-canvas')) return;

    var canvas = document.createElement('canvas');
    canvas.id = 'lawi-rain-canvas';
    canvas.setAttribute('style', [
      'position:absolute', 'inset:0', 'width:100%', 'height:100%',
      'pointer-events:none', 'z-index:0', 'border-radius:18px',
      'opacity:0.55'
    ].join(';'));

    shell.style.position = 'relative';
    shell.insertBefore(canvas, shell.firstChild);

    var ctx = canvas.getContext('2d');
    var drops = [];
    var clouds = [];
    var stars  = [];
    var zzzes  = [];
    var frame  = 0;

    function resize() {
      canvas.width  = shell.offsetWidth  || 960;
      canvas.height = shell.offsetHeight || 560;
    }

    function makeDrops() {
      drops = [];
      var n = Math.max(40, Math.floor(canvas.width / 10));
      for (var i = 0; i < n; i++) {
        drops.push({
          x:     Math.random() * canvas.width,
          y:     Math.random() * canvas.height,
          len:   12 + Math.random() * 22,
          speed: 1.2 + Math.random() * 3.2,
          alpha: 0.06 + Math.random() * 0.22,
          thick: 0.4 + Math.random() * 0.9,
          lean:  -0.3 + Math.random() * 0.6
        });
      }
    }

    function makeClouds() {
      clouds = [];
      for (var i = 0; i < 14; i++) {
        clouds.push({
          x:     Math.random() * canvas.width * 1.4 - canvas.width * 0.2,
          y:     20 + Math.random() * (canvas.height * 0.92),
          w:     90 + Math.random() * 200,
          h:     28 + Math.random() * 45,
          speed: 0.07 + Math.random() * 0.18,
          alpha: 0.04 + Math.random() * 0.09,
          puffs: 3 + Math.floor(Math.random() * 3)
        });
      }
    }

    function makeStars() {
      stars = [];
      for (var i = 0; i < 90; i++) {
        stars.push({
          x:     Math.random() * canvas.width,
          y:     Math.random() * canvas.height,
          r:     0.4 + Math.random() * 1.4,
          alpha: 0.15 + Math.random() * 0.55,
          phase: Math.random() * Math.PI * 2,
          speed: 0.008 + Math.random() * 0.025
        });
      }
    }

    function drawCloud(c) {
      ctx.save();
      var pw = c.w / (c.puffs + 1);
      for (var p = 0; p < c.puffs; p++) {
        var px = c.x + pw * p + pw * 0.5;
        var pr = (c.h / 2) * (0.7 + 0.3 * Math.sin(p * 1.1 + 0.5));
        var grad = ctx.createRadialGradient(px, c.y, 0, px, c.y, pr * 1.6);
        grad.addColorStop(0,   'rgba(210,185,255,' + c.alpha + ')');
        grad.addColorStop(0.5, 'rgba(160,120,230,' + (c.alpha * 0.6) + ')');
        grad.addColorStop(1,   'rgba(80,40,160,0)');
        ctx.beginPath();
        ctx.ellipse(px, c.y, pr * 1.6, pr, 0, 0, Math.PI * 2);
        ctx.fillStyle = grad;
        ctx.fill();
      }
      ctx.restore();
    }

    function draw() {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      frame++;

      if (_activeThemeId === 'zzz') {
        /* Stars */
        for (var i = 0; i < stars.length; i++) {
          var s = stars[i];
          s.phase += s.speed;
          var sa = s.alpha * (0.5 + 0.5 * Math.sin(s.phase));
          ctx.beginPath();
          ctx.arc(s.x, s.y, s.r, 0, Math.PI * 2);
          ctx.fillStyle = 'rgba(220,200,255,' + sa + ')';
          ctx.fill();
        }

        /* Clouds */
        for (var i = 0; i < clouds.length; i++) {
          var c = clouds[i];
          drawCloud(c);
          c.x -= c.speed;
          if (c.x + c.w < -20) {
            c.x = canvas.width + 20;
            c.y = 20 + Math.random() * (canvas.height * 0.92);
            c.alpha = 0.04 + Math.random() * 0.09;
            c.w = 90 + Math.random() * 200;
          }
        }

        /* Floating ZZZ letters */
        if (frame % 110 === 0) {
          for (var k = 0; k < 3; k++) {
            zzzes.push({
              x:    30 + Math.random() * (canvas.width - 60),
              y:    canvas.height - 10 - Math.random() * 40,
              size: 8 + Math.random() * 9,
              alpha:0.75,
              dx:  -0.2 + Math.random() * 0.4,
              dy:  -(0.35 + Math.random() * 0.5)
            });
          }
        }
        for (var i = zzzes.length - 1; i >= 0; i--) {
          var z = zzzes[i];
          ctx.save();
          ctx.globalAlpha = z.alpha;
          ctx.font = 'bold ' + z.size + 'px monospace';
          ctx.fillStyle = 'rgba(190,160,255,1)';
          ctx.fillText('z', z.x, z.y);
          ctx.restore();
          z.x += z.dx;
          z.y += z.dy;
          z.alpha -= 0.004;
          if (z.alpha <= 0) zzzes.splice(i, 1);
        }

      } else {
        /* Rain — color follows theme */
        var tc = { fent:[0,224,64], blood:[255,40,64], cyber:[0,212,255], vapor:[168,85,247], ghost:[210,210,210], light:[0,176,48] };
        var rc = tc[_activeThemeId] || tc.fent;
        for (var i = 0; i < drops.length; i++) {
          var d = drops[i];
          var g = ctx.createLinearGradient(d.x, d.y, d.x + d.lean * d.len, d.y + d.len);
          g.addColorStop(0,   'rgba(' + rc[0] + ',' + rc[1] + ',' + rc[2] + ',0)');
          g.addColorStop(0.3, 'rgba(' + rc[0] + ',' + rc[1] + ',' + rc[2] + ',' + d.alpha + ')');
          g.addColorStop(0.8, 'rgba(' + rc[0] + ',' + rc[1] + ',' + rc[2] + ',' + (d.alpha * 0.9) + ')');
          g.addColorStop(1,   'rgba(' + rc[0] + ',' + rc[1] + ',' + rc[2] + ',' + (d.alpha * 0.4) + ')');
          ctx.beginPath();
          ctx.moveTo(d.x, d.y);
          ctx.lineTo(d.x + d.lean * d.len, d.y + d.len);
          ctx.strokeStyle = g;
          ctx.lineWidth   = d.thick;
          ctx.stroke();
          d.y += d.speed;
          d.x += d.lean * 0.3;
          if (d.y > canvas.height + d.len) {
            d.y     = -d.len - Math.random() * 40;
            d.x     = Math.random() * canvas.width;
            d.alpha = 0.06 + Math.random() * 0.22;
            d.len   = 12 + Math.random() * 22;
          }
        }
      }

      requestAnimationFrame(draw);
    }

    resize();
    makeDrops();
    makeClouds();
    makeStars();
    draw();
    window.addEventListener('resize', function () { resize(); makeDrops(); makeClouds(); makeStars(); });
  }

  /* ── Welcome modal ────────────────────────────────────────────── */
  function createWelcomeModal() {
    var WELCOMED_KEY = 'lawi_welcomed_v1';
    try { if (localStorage.getItem(WELCOMED_KEY)) return; } catch (e) {}
    if (document.getElementById('lawi-welcome-overlay')) return;

    var overlay = document.createElement('div');
    overlay.id = 'lawi-welcome-overlay';
    overlay.innerHTML =
      '<div id="lawi-welcome-modal">' +
        '<div class="lawi-wm-header">' +
          '<span class="lawi-wm-logo">voidware</span>' +
          '<span class="lawi-wm-ver">v1.2</span>' +
        '</div>' +
        '<div class="lawi-wm-body">' +
          '<p class="lawi-wm-desc">Welcome. Here\'s what you need to know.</p>' +
          '<div class="lawi-wm-row">' +
            '<div class="lawi-wm-keybind"><kbd>ALT</kbd><span>+</span><kbd>L</kbd></div>' +
            '<span class="lawi-wm-row-label">Toggle GUI on / off</span>' +
          '</div>' +
          '<div class="lawi-wm-row">' +
            '<div class="lawi-wm-keybind"><kbd style="letter-spacing:0;padding:2px 5px;">⠿ drag</kbd></div>' +
            '<span class="lawi-wm-row-label">Drag brand block to reposition</span>' +
          '</div>' +
          '<div class="lawi-wm-row">' +
            '<div class="lawi-wm-keybind"><kbd>search</kbd></div>' +
            '<span class="lawi-wm-row-label">Filter controls with the search bar</span>' +
          '</div>' +
        '</div>' +
        '<button class="lawi-wm-close" id="lawi-wm-close-btn">GOT IT</button>' +
      '</div>';

    document.documentElement.appendChild(overlay);

    document.getElementById('lawi-wm-close-btn').addEventListener('click', function () {
      overlay.classList.add('lawi-wm-out');
      setTimeout(function () {
        if (overlay.parentNode) overlay.parentNode.removeChild(overlay);
      }, 300);
      try { localStorage.setItem(WELCOMED_KEY, '1'); } catch (e) {}
    });

    overlay.addEventListener('click', function (e) {
      if (e.target === overlay) document.getElementById('lawi-wm-close-btn').click();
    });
  }

  /* ── Toast notifications ──────────────────────────────────────── */
  var _toastContainer = null;

  function ensureToastContainer() {
    if (_toastContainer && _toastContainer.parentNode) return _toastContainer;
    _toastContainer = document.createElement('div');
    _toastContainer.id = 'lawi-toast-container';
    document.documentElement.appendChild(_toastContainer);
    return _toastContainer;
  }

  function showToast(message, type) {
    var container = ensureToastContainer();
    var toast = document.createElement('div');
    toast.className = 'lawi-toast lawi-toast-' + (type || 'info');
    toast.textContent = message;
    container.appendChild(toast);
    requestAnimationFrame(function () { toast.classList.add('lawi-toast-in'); });
    setTimeout(function () {
      toast.classList.remove('lawi-toast-in');
      toast.classList.add('lawi-toast-out');
      setTimeout(function () { if (toast.parentNode) toast.parentNode.removeChild(toast); }, 300);
    }, 2200);
  }

  function setupCheckboxToasts(root) {
    root.addEventListener('change', function (e) {
      var cb = e.target;
      if (cb.type !== 'checkbox') return;
      /* Skip our own right-panel toggles — they handle their own toasts */
      if (cb.classList && cb.classList.contains('lawi-rtoggle-cb')) return;
      var ctrl = cb.closest ? cb.closest('.controller') : null;
      if (!ctrl) {
        var p = cb.parentNode;
        while (p && p.classList && !p.classList.contains('controller')) p = p.parentNode;
        ctrl = (p && p.classList && p.classList.contains('controller')) ? p : null;
      }
      var nameEl = ctrl ? ctrl.querySelector('.name') : null;
      var label = nameEl ? nameEl.textContent.trim() : 'Feature';
      showToast(label + ': ' + (cb.checked ? 'ON' : 'OFF'), cb.checked ? 'on' : 'off');
    });
  }

  /* ================================================================
     CONFIG SYSTEM — themes · mode · accent
     ================================================================ */
  var LAWI_CFG_KEY = 'lawi_cfg_v1';
  var _cfgStyle    = null;

  var LAWI_THEMES = [
    { id: 'zzz', label: 'ZZZ', accent: '#b48aff', mode: 'dark' }
  ];

  var _activeThemeId = (function () { try { var c = JSON.parse(localStorage.getItem('lawi_cfg_v1')); return (c && c.theme) || 'zzz'; } catch (e) { return 'zzz'; } }());

  var LAWI_SWATCHES = [
    '#00e040','#ff2840','#00d4ff','#a855f7',
    '#ff7730','#ff3d9a','#ffd700','#e0e0e0'
  ];

  function loadCfg() {
    try {
      var c = JSON.parse(localStorage.getItem(LAWI_CFG_KEY));
      if (c && c.accent) return c;
    } catch (e) {}
    return { accent: '#b48aff', mode: 'dark', theme: 'zzz' };
  }

  function saveCfg(c) {
    try { localStorage.setItem(LAWI_CFG_KEY, JSON.stringify(c)); } catch (e) {}
  }

  function hexToRgb(hex) {
    var r = parseInt(hex.slice(1,3), 16);
    var g = parseInt(hex.slice(3,5), 16);
    var b = parseInt(hex.slice(5,7), 16);
    return r + ',' + g + ',' + b;
  }

  function applyCfg(cfg) {
    if (!_cfgStyle) {
      _cfgStyle = document.createElement('style');
      _cfgStyle.id = 'lawi-dynamic-cfg';
      (document.head || document.documentElement).appendChild(_cfgStyle);
    }
    _activeThemeId = cfg.theme || 'fent';
    var a   = cfg.accent || '#00e040';
    var rgb = hexToRgb(a);
    var dk  = cfg.mode !== 'light';
    var isZzz = _activeThemeId === 'zzz';

    var bg0  = isZzz ? '#0e0820' : (dk ? '#0f0f0f' : '#f0f0f0');
    var bg1  = isZzz ? '#140c2a' : (dk ? '#141414' : '#e8e8e8');
    var bg2  = isZzz ? '#1b1038' : (dk ? '#1a1a1a' : '#dcdcdc');
    var bg3  = isZzz ? '#201444' : (dk ? '#1e1e1e' : '#d2d2d2');
    var bg4  = isZzz ? '#271950' : (dk ? '#222222' : '#c8c8c8');
    var txt  = isZzz ? '#d8c8ff' : (dk ? '#c8c8c8' : '#1a1a1a');
    var txt2 = isZzz ? '#8870aa' : (dk ? '#777777' : '#555555');
    var bdr  = isZzz ? '#3a2060' : (dk ? '#2a2a2a' : '#bfbfbf');
    var bdr2 = isZzz ? '#2e1850' : (dk ? '#242424' : '#cbcbcb');
    var bdr3 = isZzz ? '#402878' : (dk ? '#333333' : '#b0b0b0');

    var ra       = 'rgba(' + rgb + ',';
    var pageStyles = '';
    var fs       = cfg.fontSize  || 11;
    var op       = cfg.opacity   !== undefined ? cfg.opacity : 1;
    var compact  = cfg.compact   ? '22px' : '26px';

    _cfgStyle.textContent = pageStyles + [
      '.lil-gui{--focus-color:' + a + ' !important;--number-color:' + a + ' !important;--title-text-color:' + a + ' !important;--text-color:' + txt + ' !important;--background-color:' + bg1 + ' !important;--widget-color:' + bg3 + ' !important;--hover-color:' + bg4 + ' !important;}',
      '#lawi-glass-shell{background:' + bg0 + ' !important;box-shadow:0 0 0 1px ' + bdr + ',0 8px 32px rgba(0,0,0,0.8) !important;}',
      '.lil-gui.root>#lawi-glass-shell::before{background:' + a + ' !important;}',
      '#lawi-left{background:' + bg1 + ' !important;border-right-color:' + bdr2 + ' !important;}',
      '#lawi-right{background:' + bg1 + ' !important;border-left-color:' + bdr2 + ' !important;}',
      '.lawi-brand-name{color:' + a + ' !important;text-shadow:0 0 10px ' + ra + '0.5) !important;}',
      '.lawi-brand-tagline{color:' + ra + '0.5) !important;background:' + ra + '0.08) !important;border-color:' + ra + '0.2) !important;}',
      '.lawi-nav-btn:hover{background:' + ra + '0.06) !important;color:' + a + ' !important;border-color:' + ra + '0.2) !important;}',
      '.lawi-nav-btn.lawi-nav-btn-active{background:' + ra + '0.1) !important;color:' + a + ' !important;border-color:' + ra + '0.35) !important;}',
      '.lawi-nav-btn.lawi-nav-btn-active::before{background:' + a + ' !important;}',
      '.lawi-nav-btn.lawi-nav-btn-active .lawi-nav-icon{filter:drop-shadow(0 0 4px ' + ra + '0.7)) !important;}',
      '.lawi-col{background:' + bg1 + ' !important;border-color:' + bdr + ' !important;}',
      '.lawi-col-tabwrap{background:' + bg0 + ' !important;border-bottom-color:' + bdr + ' !important;}',
      '.lawi-col-tab{color:' + txt2 + ' !important;}',
      '.lawi-col-tab:hover{color:' + a + ' !important;}',
      '.lawi-col-tab.lawi-col-tab-active{color:' + a + ' !important;border-bottom-color:' + a + ' !important;}',
      '.lawi-col-content .lil-gui .lil-gui>.title{color:' + txt + ' !important;border-left-color:' + a + ' !important;border-top-color:' + bdr2 + ' !important;border-bottom-color:' + bdr2 + ' !important;}',
      '.lil-gui .controller>.name{color:' + txt2 + ' !important;}',
      '.lil-gui .controller:hover>.name{color:' + txt + ' !important;}',
      '.lil-gui input[type=text],.lil-gui input[type=number]{background:' + bg3 + ' !important;border-color:' + bdr3 + ' !important;color:' + txt + ' !important;}',
      '.lil-gui input[type=text]:hover,.lil-gui input[type=number]:hover,.lil-gui input[type=text]:focus,.lil-gui input[type=number]:focus{border-color:' + a + ' !important;}',
      '.lil-gui .controller.number .slider{background:' + bg4 + ' !important;border-color:' + bdr + ' !important;}',
      '.lil-gui .controller.number .fill{background:' + a + ' !important;}',
      '.lil-gui .controller.number.hasSlider input{color:' + a + ' !important;}',
      '.lil-gui input[type=checkbox]:hover{border-color:' + a + ' !important;}',
      '.lil-gui input[type=checkbox]:checked{border-color:' + a + ' !important;}',
      '.lil-gui input[type=checkbox]:checked::before{content:"✓" !important;color:' + a + ' !important;background:transparent !important;text-shadow:0 0 6px ' + ra + '0.6) !important;box-shadow:none !important;}',
      '.lil-gui .controller.option .display{background:' + bg3 + ' !important;border-color:' + bdr3 + ' !important;color:' + txt + ' !important;}',
      '.lil-gui .controller.option .widget:hover .display{border-color:' + a + ' !important;}',
      '.lil-gui .controller button{border-color:' + a + ' !important;color:' + a + ' !important;background:' + bg3 + ' !important;}',
      '.lil-gui .controller button:hover{background:' + ra + '0.12) !important;}',
      '.lawi-status-badge{color:' + ra + '0.9) !important;background:' + ra + '0.07) !important;border-color:' + ra + '0.2) !important;}',
      '.lawi-status-dot{background:' + a + ' !important;box-shadow:0 0 5px ' + ra + '0.7) !important;}',
      '.lawi-inv-section{border-color:' + bdr + ' !important;background:' + bg1 + ' !important;}',
      '.lawi-inv-toggle{color:' + txt + ' !important;}',
      '.lawi-inv-count{color:' + ra + '0.6) !important;background:' + ra + '0.08) !important;border-color:' + ra + '0.15) !important;}',
      '.lawi-avatar-title{color:' + ra + '0.6) !important;}',
      '.lawi-avatar-ver{color:' + ra + '0.5) !important;background:' + ra + '0.08) !important;}',
      '.lawi-avatar-username{color:' + txt + ' !important;}',
      '.lawi-avatar-id{color:' + txt2 + ' !important;}',
      '.lawi-avatar-frame{background:' + bg2 + ' !important;border-color:' + bdr + ' !important;}',
      '.lawi-avatar-header{border-bottom-color:' + bdr2 + ' !important;}',
      '.lawi-left-footer{border-top-color:' + bdr2 + ' !important;}',
      '.lawi-brand-block{border-bottom-color:' + bdr2 + ' !important;}',
      '.lawi-search-input{background:' + bg1 + ' !important;border-color:' + bdr + ' !important;color:' + txt + ' !important;}',
      '.lawi-search-input:focus{border-color:' + a + ' !important;}',
      '.lawi-kb-key{background:' + bg2 + ' !important;border-color:' + bdr3 + ' !important;}',
      '.lawi-keybind-hint:hover .lawi-kb-key{color:' + ra + '0.7) !important;border-color:' + ra + '0.25) !important;}',
      '.lawi-toast{background:' + bg1 + ' !important;border-color:' + bdr + ' !important;color:' + txt + ' !important;}',
      '.lawi-toast-on{border-left-color:' + a + ' !important;}',
      '#lawi-cfg-panel{background:' + bg1 + ' !important;border-color:' + bdr + ' !important;border-top-color:' + a + ' !important;}',
      '.lawi-cfg-title{color:' + a + ' !important;}',
      '.lawi-cfg-drag-hint{color:' + txt2 + ' !important;}',
      '.lawi-cfg-header{border-bottom-color:' + bdr + ' !important;}',
      '.lawi-cfg-section-title{color:' + ra + '0.65) !important;border-bottom-color:' + bdr2 + ' !important;}',
      '.lawi-cfg-label{color:' + txt2 + ' !important;}',
      '.lawi-cfg-mode-btn{background:' + bg3 + ' !important;border-color:' + bdr3 + ' !important;color:' + txt2 + ' !important;}',
      '.lawi-cfg-mode-btn.lawi-active{border-color:' + a + ' !important;color:' + a + ' !important;background:' + ra + '0.08) !important;}',
      '.lawi-cfg-theme-btn{background:' + bg3 + ' !important;border-color:' + bdr3 + ' !important;color:' + txt2 + ' !important;}',
      '.lawi-cfg-theme-btn.lawi-active{border-color:' + a + ' !important;color:' + a + ' !important;background:' + ra + '0.08) !important;}',
      '.lawi-cfg-swatch.lawi-active{box-shadow:0 0 0 2px ' + bg0 + ',0 0 0 4px ' + a + ' !important;}',
      '.lawi-cfg-custom-input{background:' + bg3 + ' !important;border-color:' + bdr3 + ' !important;color:' + txt + ' !important;}',
      '.lawi-cfg-custom-input:focus{border-color:' + a + ' !important;}',
      '.lil-gui{--font-size:' + fs + 'px !important;--input-font-size:' + fs + 'px !important;--widget-height:' + compact + ' !important;--title-height:' + compact + ' !important;}',
      '.lil-gui .controller>.name{font-size:' + fs + 'px !important;}',
      '#lawi-glass-shell{opacity:' + op + ' !important;}',
      '#lawi-cfg-panel{opacity:' + op + ' !important;}',
    ].join('');
  }

  /* ── Config panel ──────────────────────────────────────────────── */
  function createConfigPanel() {
    var existing = document.getElementById('lawi-cfg-panel');
    if (existing) { existing.classList.remove('lawi-hidden'); return; }

    var cfg = loadCfg();
    applyCfg(cfg);

    var panel = document.createElement('div');
    panel.id = 'lawi-cfg-panel';

    /* Header */
    panel.innerHTML =
      '<div class="lawi-cfg-header" id="lawi-cfg-drag-handle">' +
        '<span class="lawi-cfg-title">CONFIG</span>' +
        '<span class="lawi-cfg-drag-hint">⠿ drag</span>' +
      '</div>' +
      '<div class="lawi-cfg-body">' +

        /* Theme presets */
        '<div class="lawi-cfg-section">' +
          '<div class="lawi-cfg-section-title">THEME</div>' +
          '<div class="lawi-cfg-theme-grid" id="lawi-cfg-themes"></div>' +
        '</div>' +

        /* Mode */
        '<div class="lawi-cfg-section">' +
          '<div class="lawi-cfg-section-title">MODE</div>' +
          '<div class="lawi-cfg-row">' +
            '<button class="lawi-cfg-mode-btn" id="lawi-cfg-dark">DARK</button>' +
            '<button class="lawi-cfg-mode-btn" id="lawi-cfg-light">LIGHT</button>' +
          '</div>' +
        '</div>' +

        /* Accent */
        '<div class="lawi-cfg-section">' +
          '<div class="lawi-cfg-section-title">ACCENT</div>' +
          '<div class="lawi-cfg-swatches" id="lawi-cfg-swatches"></div>' +
          '<div class="lawi-cfg-custom-row">' +
            '<span class="lawi-cfg-label">Custom</span>' +
            '<input type="text" class="lawi-cfg-custom-input" id="lawi-cfg-custom" maxlength="7" placeholder="#00e040">' +
            '<input type="color" class="lawi-cfg-color-native" id="lawi-cfg-color-pick">' +
          '</div>' +
        '</div>' +

        /* Font size */
        '<div class="lawi-cfg-section">' +
          '<div class="lawi-cfg-section-title">FONT SIZE</div>' +
          '<div class="lawi-cfg-slider-row">' +
            '<input type="range" min="9" max="14" step="1" class="lawi-cfg-range" id="lawi-cfg-fontsize">' +
            '<span class="lawi-cfg-range-val" id="lawi-cfg-fontsize-val">11px</span>' +
          '</div>' +
        '</div>' +

        /* Opacity */
        '<div class="lawi-cfg-section">' +
          '<div class="lawi-cfg-section-title">OPACITY</div>' +
          '<div class="lawi-cfg-slider-row">' +
            '<input type="range" min="30" max="100" step="5" class="lawi-cfg-range" id="lawi-cfg-opacity">' +
            '<span class="lawi-cfg-range-val" id="lawi-cfg-opacity-val">100%</span>' +
          '</div>' +
        '</div>' +

        /* Compact + Export */
        '<div class="lawi-cfg-section">' +
          '<div class="lawi-cfg-section-title">DISPLAY</div>' +
          '<div class="lawi-cfg-row">' +
            '<button class="lawi-cfg-mode-btn" id="lawi-cfg-compact">COMPACT</button>' +
          '</div>' +
        '</div>' +

        '<div class="lawi-cfg-section">' +
          '<div class="lawi-cfg-section-title">CONFIG</div>' +
          '<div class="lawi-cfg-row">' +
            '<button class="lawi-cfg-mode-btn" id="lawi-cfg-export">EXPORT</button>' +
            '<button class="lawi-cfg-mode-btn" id="lawi-cfg-import">IMPORT</button>' +
          '</div>' +
        '</div>' +

      '</div>';

    document.documentElement.appendChild(panel);

    /* Position: top-right of viewport */
    panel.style.cssText = 'position:fixed;top:60px;right:20px;z-index:99998;';

    /* Populate theme buttons */
    var themeGrid = document.getElementById('lawi-cfg-themes');
    LAWI_THEMES.forEach(function (t) {
      var btn = document.createElement('button');
      btn.className = 'lawi-cfg-theme-btn' + (cfg.theme === t.id ? ' lawi-active' : '');
      btn.textContent = t.label;
      btn.style.setProperty('--t-accent', t.accent);
      btn.addEventListener('click', function () {
        cfg.theme  = t.id;
        cfg.accent = t.accent;
        cfg.mode   = t.mode;
        saveCfg(cfg);
        applyCfg(cfg);
        refreshCfgPanel(cfg);
      });
      themeGrid.appendChild(btn);
    });

    /* Populate swatches */
    var swatchWrap = document.getElementById('lawi-cfg-swatches');
    LAWI_SWATCHES.forEach(function (color) {
      var sw = document.createElement('button');
      sw.className = 'lawi-cfg-swatch' + (cfg.accent === color ? ' lawi-active' : '');
      sw.style.background = color;
      sw.title = color;
      sw.addEventListener('click', function () {
        cfg.accent = color;
        cfg.theme  = 'custom';
        saveCfg(cfg);
        applyCfg(cfg);
        refreshCfgPanel(cfg);
      });
      swatchWrap.appendChild(sw);
    });

    /* Mode buttons */
    document.getElementById('lawi-cfg-dark').classList.toggle('lawi-active', cfg.mode !== 'light');
    document.getElementById('lawi-cfg-light').classList.toggle('lawi-active', cfg.mode === 'light');

    document.getElementById('lawi-cfg-dark').addEventListener('click', function () {
      cfg.mode = 'dark'; cfg.theme = 'custom';
      saveCfg(cfg); applyCfg(cfg); refreshCfgPanel(cfg);
    });
    document.getElementById('lawi-cfg-light').addEventListener('click', function () {
      cfg.mode = 'light'; cfg.theme = 'custom';
      saveCfg(cfg); applyCfg(cfg); refreshCfgPanel(cfg);
    });

    /* Custom hex input */
    var customInput = document.getElementById('lawi-cfg-custom');
    var colorPick   = document.getElementById('lawi-cfg-color-pick');
    customInput.value = cfg.accent;
    colorPick.value   = cfg.accent;

    customInput.addEventListener('input', function () {
      var v = customInput.value.trim();
      if (/^#[0-9a-fA-F]{6}$/.test(v)) {
        cfg.accent = v; cfg.theme = 'custom';
        colorPick.value = v;
        saveCfg(cfg); applyCfg(cfg); refreshCfgPanel(cfg);
      }
    });
    colorPick.addEventListener('input', function () {
      cfg.accent = colorPick.value; cfg.theme = 'custom';
      customInput.value = cfg.accent;
      saveCfg(cfg); applyCfg(cfg); refreshCfgPanel(cfg);
    });

    /* Font size */
    var fsSlider = document.getElementById('lawi-cfg-fontsize');
    var fsVal    = document.getElementById('lawi-cfg-fontsize-val');
    if (fsSlider) {
      fsSlider.value = cfg.fontSize || 11;
      fsVal.textContent = (cfg.fontSize || 11) + 'px';
      fsSlider.addEventListener('input', function () {
        cfg.fontSize = parseInt(fsSlider.value);
        fsVal.textContent = cfg.fontSize + 'px';
        saveCfg(cfg); applyCfg(cfg);
      });
    }

    /* Opacity */
    var opSlider = document.getElementById('lawi-cfg-opacity');
    var opVal    = document.getElementById('lawi-cfg-opacity-val');
    if (opSlider) {
      var initOp = cfg.opacity !== undefined ? Math.round(cfg.opacity * 100) : 100;
      opSlider.value = initOp;
      opVal.textContent = initOp + '%';
      opSlider.addEventListener('input', function () {
        cfg.opacity = parseInt(opSlider.value) / 100;
        opVal.textContent = Math.round(cfg.opacity * 100) + '%';
        saveCfg(cfg); applyCfg(cfg);
      });
    }

    /* Compact */
    var compBtn = document.getElementById('lawi-cfg-compact');
    if (compBtn) {
      compBtn.classList.toggle('lawi-active', !!cfg.compact);
      compBtn.addEventListener('click', function () {
        cfg.compact = !cfg.compact;
        compBtn.classList.toggle('lawi-active', cfg.compact);
        saveCfg(cfg); applyCfg(cfg);
      });
    }

    /* Export / Import */
    document.getElementById('lawi-cfg-export').addEventListener('click', function () {
      var json = JSON.stringify(cfg, null, 2);
      try { navigator.clipboard.writeText(json).then(function () { showToast('Config copied to clipboard', 'on'); }); }
      catch (e) { showToast('Config copied!', 'on'); }
    });
    document.getElementById('lawi-cfg-import').addEventListener('click', function () {
      try {
        navigator.clipboard.readText().then(function (text) {
          try {
            var parsed = JSON.parse(text);
            if (parsed && parsed.accent) {
              Object.assign(cfg, parsed);
              saveCfg(cfg); applyCfg(cfg); refreshCfgPanel(cfg);
              showToast('Config imported!', 'on');
            }
          } catch (e) { showToast('Invalid config JSON', 'off'); }
        });
      } catch (e) { showToast('Clipboard not available', 'off'); }
    });

    /* Drag */
    var handle = document.getElementById('lawi-cfg-drag-handle');
    var dragActive = false, sx = 0, sy = 0, sl = 0, st = 0;
    handle.addEventListener('mousedown', function (e) {
      if (e.button !== 0) return;
      dragActive = true;
      var r = panel.getBoundingClientRect();
      sl = r.left; st = r.top; sx = e.clientX; sy = e.clientY;
      panel.style.right = 'auto';
      panel.style.left  = sl + 'px';
      panel.style.top   = st + 'px';
      document.addEventListener('mousemove', onDragMove);
      document.addEventListener('mouseup',   onDragUp);
      e.preventDefault();
    });
    function onDragMove(e) {
      if (!dragActive) return;
      panel.style.left = Math.max(0, sl + e.clientX - sx) + 'px';
      panel.style.top  = Math.max(0, st + e.clientY - sy) + 'px';
    }
    function onDragUp() {
      dragActive = false;
      document.removeEventListener('mousemove', onDragMove);
      document.removeEventListener('mouseup',   onDragUp);
    }
  }

  function refreshCfgPanel(cfg) {
    /* Theme buttons */
    document.querySelectorAll('.lawi-cfg-theme-btn').forEach(function (b) {
      b.classList.toggle('lawi-active', b.textContent === (LAWI_THEMES.find(function(t){ return t.id === cfg.theme; }) || {}).label);
    });
    /* Mode buttons */
    var darkBtn  = document.getElementById('lawi-cfg-dark');
    var lightBtn = document.getElementById('lawi-cfg-light');
    if (darkBtn)  darkBtn.classList.toggle('lawi-active',  cfg.mode !== 'light');
    if (lightBtn) lightBtn.classList.toggle('lawi-active', cfg.mode === 'light');
    /* Swatches */
    document.querySelectorAll('.lawi-cfg-swatch').forEach(function (sw) {
      sw.classList.toggle('lawi-active', sw.style.background === cfg.accent || sw.title === cfg.accent);
    });
    /* Inputs */
    var ci = document.getElementById('lawi-cfg-custom');
    var cp = document.getElementById('lawi-cfg-color-pick');
    if (ci) ci.value = cfg.accent;
    if (cp) cp.value = cfg.accent;
  }

  /* ── / key → focus search ───────────────────────────────────── */
  function setupSlashSearch() {
    document.addEventListener('keydown', function (e) {
      if (e.key !== '/') return;
      var a = document.activeElement;
      if (a && (a.tagName === 'INPUT' || a.tagName === 'TEXTAREA' || a.isContentEditable)) return;
      var s = document.querySelector('.lawi-search-input');
      if (!s) return;
      e.preventDefault();
      s.focus(); s.select();
    }, true);
  }

  /* ── Nav badges — active checkbox count per section ─────────── */
  function updateNavBadge(folder, badge) {
    var n = folder.querySelectorAll('input[type=checkbox]:checked').length;
    badge.textContent = n;
    badge.style.display = n > 0 ? 'flex' : 'none';
  }
  function setupNavBadge(folder, badge) {
    updateNavBadge(folder, badge);
    folder.addEventListener('change', function (e) {
      if (e.target && e.target.type === 'checkbox') updateNavBadge(folder, badge);
    });
  }

  /* ── Status bar ──────────────────────────────────────────────── */
  function createStatusBar(center, root) {
    var bar = document.createElement('div');
    bar.id = 'lawi-statusbar';
    bar.innerHTML = '<span id="lawi-status-txt">0 features active</span>';
    center.appendChild(bar);
    function upd() {
      var el = document.getElementById('lawi-status-txt');
      if (!el) return;
      var n = root.querySelectorAll('input[type=checkbox]:checked').length;
      el.textContent = n + ' feature' + (n !== 1 ? 's' : '') + ' active';
    }
    upd();
    root.addEventListener('change', function (e) { if (e.target && e.target.type === 'checkbox') upd(); });
  }

  /* ── Auto-hide on inactivity ─────────────────────────────────── */
  function setupAutoHide(shell) {
    var DELAY = 12000;
    var timer = null;
    function arm() {
      clearTimeout(timer);
      timer = setTimeout(function () {
        var r = document.querySelector('.lil-gui.root');
        if (!r || r.classList.contains('lawi-hidden')) return;
        r.classList.add('lawi-hidden');
        var cp = document.getElementById('lawi-cfg-panel');
        if (cp) cp.classList.add('lawi-hidden');
        try { localStorage.setItem(PANEL_KEY, '1'); } catch (e) {}
      }, DELAY);
    }
    function disarm() { clearTimeout(timer); }
    shell.addEventListener('mouseenter', disarm);
    shell.addEventListener('mouseleave', arm);
    setTimeout(function () {
      var cp = document.getElementById('lawi-cfg-panel');
      if (cp) { cp.addEventListener('mouseenter', disarm); cp.addEventListener('mouseleave', arm); }
    }, 200);
  }

  /* ── Copy buttons on inputs ──────────────────────────────────── */
  function addCopyBtn(ctrl) {
    if (ctrl.dataset.cpAdded) return;
    ctrl.dataset.cpAdded = '1';
    var input = ctrl.querySelector('input[type=text], input[type=number]');
    if (!input) return;
    var btn = document.createElement('button');
    btn.className = 'lawi-copy-btn';
    btn.title = 'Copy value';
    btn.innerHTML = '<svg width="9" height="9" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>';
    btn.addEventListener('click', function (e) {
      e.stopPropagation();
      var val = input.value;
      try { navigator.clipboard.writeText(val).then(function () { showToast('Copied: ' + val, 'info'); }); }
      catch (ex) { showToast('Copied: ' + val, 'info'); }
    });
    ctrl.style.position = 'relative';
    ctrl.appendChild(btn);
  }
  function setupCopyButtons(root) {
    root.querySelectorAll('.controller.string, .controller.number').forEach(addCopyBtn);
  }

  /* ── Right-click context menu ────────────────────────────────── */
  var _ctx = null;
  function closeCtx() { if (_ctx && _ctx.parentNode) _ctx.parentNode.removeChild(_ctx); _ctx = null; }
  function openCtx(x, y, ctrl) {
    closeCtx();
    var menu = document.createElement('div');
    menu.id = 'lawi-ctx-menu';
    _ctx = menu;
    function item(lbl, fn) {
      var d = document.createElement('div');
      d.className = 'lawi-ctx-item';
      d.textContent = lbl;
      d.addEventListener('click', function () { closeCtx(); fn(); });
      menu.appendChild(d);
    }
    var inp = ctrl.querySelector('input');
    var nameEl = ctrl.querySelector('.name');
    var lbl = nameEl ? nameEl.textContent.trim() : '';
    var val = inp ? inp.value : '';
    item('Copy label', function () {
      try { navigator.clipboard.writeText(lbl); } catch (e) {}
      showToast('Copied: ' + lbl, 'info');
    });
    if (inp && inp.type !== 'checkbox') {
      item('Copy value', function () {
        try { navigator.clipboard.writeText(val); } catch (e) {}
        showToast('Copied: ' + val, 'info');
      });
    }
    if (inp && inp.type === 'checkbox') {
      item('Toggle', function () { inp.click(); });
    }
    var sep = document.createElement('div'); sep.className = 'lawi-ctx-sep'; menu.appendChild(sep);
    item('Close', closeCtx);
    menu.style.cssText = 'position:fixed;left:' + x + 'px;top:' + y + 'px;z-index:2147483646;';
    document.documentElement.appendChild(menu);
    setTimeout(function () { document.addEventListener('mousedown', closeCtx, { once: true }); }, 10);
  }
  function setupContextMenu(root) {
    root.addEventListener('contextmenu', function (e) {
      var ctrl = e.target.closest ? e.target.closest('.controller') : null;
      if (!ctrl) return;
      e.preventDefault();
      openCtx(e.clientX, e.clientY, ctrl);
    });
  }

  /* ── Helpers ─────────────────────────────────────────────────── */
  function escHtml(s) { return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }

  function observe() {
    injectFonts();
    createBlurBackdrop();
    applyCfg(loadCfg()); /* apply saved theme immediately */
    setupSlashSearch();

    /* Fire sora-auth-granted as a safety net in case content.js missed
       the earlier dispatch from pre-auth.js (e.g. it defers its listener). */
    try {
      window.dispatchEvent(new CustomEvent('sora-auth-granted', {
        detail: { key: '', data: { valid: true, expires: null, discord: '', note: '' } }
      }));
    } catch (e) {}

    document.querySelectorAll('.lil-gui.root').forEach(function (r) {
      if (r.dataset.lawiInit) return;
      hideIfStored(r);
      createOverlay();
      setupGui(r);
    });

    var mo = new MutationObserver(function (mutations) {
      for (var i = 0; i < mutations.length; i++) {
        var added = mutations[i].addedNodes;
        for (var j = 0; j < added.length; j++) {
          var node = added[j];
          if (node.nodeType !== 1) continue;
          if (node.classList && node.classList.contains('lil-gui') && node.classList.contains('root')) {
            mo.disconnect();
            scheduleSetup(node);
            return;
          }
          if (node.querySelectorAll) {
            var root = node.querySelector('.lil-gui.root');
            if (root) { mo.disconnect(); scheduleSetup(root); return; }
          }
        }
      }
    });
    mo.observe(document.documentElement, { childList: true, subtree: true });
  }

  /* ── Alt+L — toggle panel + overlay + persist ───────────────── */
  document.addEventListener('keydown', function (e) {
    if (!e.altKey) return;
    if (e.key !== 'l' && e.key !== 'L' && e.code !== 'KeyL') return;

    e.preventDefault();
    e.stopImmediatePropagation();

    var root     = document.querySelector('.lil-gui.root');
    var ov       = document.getElementById('lawi-overlay');
    var backdrop = document.getElementById('lawi-blur-backdrop');
    var cfgPanel = document.getElementById('lawi-cfg-panel');

    if (!root) {
      document.dispatchEvent(new KeyboardEvent('keydown', {
        key: 'y', code: 'KeyY', keyCode: 89, altKey: true,
        bubbles: true, cancelable: true
      }));
      return;
    }

    var isHidden = root.classList.contains('lawi-hidden');

    if (isHidden) {
      root.classList.remove('lawi-hidden');
      root.style.removeProperty('display');
      if (ov)       { ov.classList.remove('lawi-hidden'); ov.style.removeProperty('display'); }
      if (backdrop) { backdrop.classList.remove('lawi-hidden'); backdrop.style.removeProperty('display'); }
      if (cfgPanel) { cfgPanel.classList.remove('lawi-hidden'); cfgPanel.style.removeProperty('display'); }
      else          { createConfigPanel(); }
      try { localStorage.setItem(PANEL_KEY, '0'); } catch (e2) {}
    } else {
      root.classList.add('lawi-hidden');
      if (ov)       ov.classList.add('lawi-hidden');
      if (backdrop) backdrop.classList.add('lawi-hidden');
      if (cfgPanel) cfgPanel.classList.add('lawi-hidden');
      try { localStorage.setItem(PANEL_KEY, '1'); } catch (e2) {}
    }

    document.dispatchEvent(new KeyboardEvent('keydown', {
      key: 'y', code: 'KeyY', keyCode: 89, altKey: true,
      bubbles: true, cancelable: true
    }));
  }, true);

  /* ── Boot ────────────────────────────────────────────────────── */
  fetchPrimedState(function (primed) { isPrimed = primed; });

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', observe);
  } else {
    observe();
  }

})();