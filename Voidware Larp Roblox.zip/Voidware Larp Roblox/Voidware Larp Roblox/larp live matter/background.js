/* ================================================================
   /zzzs — background.js
   Server-based key auth · HWID-locked · Session renewal
   ================================================================ */

const KEY_SERVER_URL = 'https://dbot-production-4609.up.railway.app';

/* ── Message Handlers ─────────────────────────────────────────── */
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {

  if (msg.type === 'bridge-request') {
    const opts = { method: msg.method || 'GET' };
    if (msg.body) {
      opts.headers = { 'Content-Type': 'application/json' };
      opts.body = msg.body;
    }
    fetch(msg.url, opts)
      .then(r => r.json())
      .then(data => sendResponse({ ok: true, data }))
      .catch(err  => sendResponse({ ok: false, error: err.message }));
    return true;
  }

  if (msg.type === 'lawi-key-validate' || msg.type === 'license-validate') {
    handleKeyValidate(msg.key || '', sendResponse);
    return true;
  }

  if (msg.type === 'get-extension-url') {
    sendResponse({ url: chrome.runtime.getURL(msg.path || '') });
    return false;
  }

  if (msg.type === 'save-spoof-config') {
    chrome.storage.local.set({ lawi_spoof_config: msg.config }, () => sendResponse({ ok: true }));
    return true;
  }
  if (msg.type === 'get-spoof-config') {
    chrome.storage.local.get('lawi_spoof_config', result =>
      sendResponse({ ok: true, config: result.lawi_spoof_config || null }));
    return true;
  }
  if (msg.type === 'clear-spoof-config') {
    chrome.storage.local.remove('lawi_spoof_config', () => sendResponse({ ok: true }));
    return true;
  }

  if (msg.type === 'lawi-key-status') {
    handleKeyStatus(sendResponse);
    return true;
  }

  if (msg.type === 'lawi-key-clear') {
    clearCachedAuth();
    sendResponse({ ok: true });
    return false;
  }

  if (msg.type === 'lawi-get-primed') {
    chrome.storage.local.get(STORE.PRIMED, r =>
      sendResponse({ primed: !!r[STORE.PRIMED] }));
    return true;
  }
});

/* ── Storage Keys ─────────────────────────────────────────────── */
const STORE = {
  CACHE:  'lawi_key_cache',
  HWID:   'lawi_hwid',
  PRIMED: 'lawi_primed',
};

const SESSION_TTL_MS = 15 * 60 * 1000;
const GRACE_MS       =  2 * 60 * 1000;

/* ── HWID ─────────────────────────────────────────────────────── */
function getOrCreateHwid() {
  return new Promise(resolve => {
    chrome.storage.local.get(STORE.HWID, r => {
      let hwid = r[STORE.HWID];
      if (!hwid) {
        hwid = crypto.randomUUID
          ? crypto.randomUUID()
          : Array.from(crypto.getRandomValues(new Uint8Array(16)))
              .map(b => b.toString(16).padStart(2, '0')).join('');
        chrome.storage.local.set({ [STORE.HWID]: hwid });
      }
      resolve(hwid);
    });
  });
}

/* ── Cache ────────────────────────────────────────────────────── */
function getCache() {
  return new Promise(resolve =>
    chrome.storage.local.get(STORE.CACHE, r => resolve(r[STORE.CACHE] || null)));
}

function setCache(key, data) {
  const entry = {
    key,
    valid:        true,
    expires:      data.expires      || null,
    discord:      data.discord      || '',
    note:         data.note         || '',
    sessionToken: data.sessionToken || null,
    sessionExp:   data.sessionExp   || (Date.now() + SESSION_TTL_MS),
    cachedAt:     Date.now(),
  };
  chrome.storage.local.set({ [STORE.CACHE]: entry });
  return entry;
}

function clearCachedAuth() {
  chrome.storage.local.remove(STORE.CACHE);
}

/* ── Server Calls ─────────────────────────────────────────────── */
async function serverValidate(key, hwid) {
  const res = await fetch(`${KEY_SERVER_URL}/validate`, {
    method:  'POST',
    headers: { 'Content-Type': 'application/json' },
    body:    JSON.stringify({ key, hwid }),
  });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return res.json();
}

async function serverCheckSession(sessionToken, hwid) {
  const res = await fetch(`${KEY_SERVER_URL}/check-session`, {
    method:  'POST',
    headers: { 'Content-Type': 'application/json' },
    body:    JSON.stringify({ sessionToken, hwid }),
  });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return res.json();
}

/* ── Key Validation ───────────────────────────────────────────── */
async function handleKeyValidate(key, sendResponse) {
  try {
    const hwid   = await getOrCreateHwid();
    const cached = await getCache();

    /* Use cache if same key, session still valid */
    if (
      cached && cached.key === key.trim().toUpperCase() && cached.valid &&
      cached.sessionExp > Date.now() &&
      (!cached.expires || cached.expires > Date.now())
    ) {
      return sendResponse({ ok: true, data: cached });
    }

    let data;
    try {
      data = await serverValidate(key, hwid);
    } catch (netErr) {
      /* Offline grace: serve cache if session not yet expired */
      if (cached && cached.key === key.trim().toUpperCase() && cached.sessionExp > Date.now()) {
        return sendResponse({ ok: true, data: { ...cached, offline: true } });
      }
      return sendResponse({ ok: false, data: { valid: false, error: 'Key server unreachable. Make sure key-server.js is running.' } });
    }

    if (data.valid) {
      const entry = setCache(key.trim().toUpperCase(), data);
      sendResponse({ ok: true, data: entry });
    } else {
      clearCachedAuth();
      sendResponse({ ok: false, data: { valid: false, error: data.error || 'Invalid key.' } });
    }
  } catch (err) {
    sendResponse({ ok: false, data: { valid: false, error: err.message } });
  }
}

/* ── Key Status ───────────────────────────────────────────────── */
async function handleKeyStatus(sendResponse) {
  const cached = await getCache();
  const valid  = !!(
    cached && cached.valid &&
    (!cached.expires || cached.expires > Date.now())
  );
  sendResponse({ ok: true, valid, data: valid ? cached : null });
}

/* ── Session Renewal ──────────────────────────────────────────── */
async function renewSession() {
  const cached = await getCache();
  if (!cached || !cached.sessionToken) return;

  const hwid = await getOrCreateHwid();
  try {
    const data = await serverCheckSession(cached.sessionToken, hwid);
    if (data.valid) {
      cached.cachedAt   = Date.now();
      cached.sessionExp = Date.now() + SESSION_TTL_MS;
      if (data.discord) cached.discord = data.discord;
      chrome.storage.local.set({ [STORE.CACHE]: cached });
    } else {
      clearCachedAuth();
    }
  } catch (netErr) {
    /* Give a 2-minute grace before wiping the cache */
    if (Date.now() - cached.cachedAt > GRACE_MS) clearCachedAuth();
  }
}

chrome.alarms.create('lawi-session-check', { periodInMinutes: 5 });
chrome.alarms.onAlarm.addListener(alarm => {
  if (alarm.name === 'lawi-session-check') renewSession();
});

/* ── Auto-reload Roblox tabs on extension update ─────────────── */
chrome.runtime.onInstalled.addListener(details => {
  if (details.reason === 'update' || details.reason === 'install') {
    chrome.tabs.query({ url: 'https://www.roblox.com/*' }, tabs => {
      tabs.forEach(tab => { if (tab.id) chrome.tabs.reload(tab.id); });
    });
  }
});

/* ── Extension Icon ───────────────────────────────────────────── */
function applyPrimedBadge(primed) {
  chrome.action.setBadgeText({ text: primed ? 'ON' : '' });
  chrome.action.setBadgeBackgroundColor({ color: '#a855f7' });
}

chrome.storage.local.get(STORE.PRIMED, r => applyPrimedBadge(!!r[STORE.PRIMED]));

chrome.action.onClicked.addListener(tab => {
  chrome.storage.local.get(STORE.PRIMED, r => {
    const newState = !r[STORE.PRIMED];
    chrome.storage.local.set({ [STORE.PRIMED]: newState }, () => {
      applyPrimedBadge(newState);
      if (tab && tab.id) {
        chrome.tabs.sendMessage(tab.id, { type: 'lawi-primed-changed', primed: newState })
          .catch(() => {});
      }
    });
  });
});
