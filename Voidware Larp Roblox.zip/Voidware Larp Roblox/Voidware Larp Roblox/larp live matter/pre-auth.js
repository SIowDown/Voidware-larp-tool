(function () {
  'use strict';

  (function injectHideStyle() {
    var el = document.createElement('style');
    el.id = 'lawi-prehide-blf';
    el.textContent = '.lil-gui.root:not(.lawi-panel-visible){display:none!important;visibility:hidden!important}';
    var h = document.head || document.documentElement;
    if (h) h.appendChild(el);
  })();

  (function writeFakeLicense() {
    try {
      var payload = JSON.stringify({ valid: true, key: 'BYPASS', expires: null, discord: '', note: '' });
      localStorage.setItem('bloxflare_license',      'BYPASS');
      localStorage.setItem('bloxflare_license_data', payload);
      localStorage.setItem('sora_license',           'BYPASS');
      localStorage.setItem('sora_license_data',      payload);
      // Also write voidware keys for consistency
      localStorage.setItem('voidware_license',       'BYPASS');
      localStorage.setItem('voidware_license_data',  payload);
    } catch (e) {}
  })();

  var _origDispatch = window.dispatchEvent.bind(window);

  window.addEventListener('bloxflare-relay-request', function (e) {
    if (!e || !e.detail || !e.detail.msg) return;
    var msg = e.detail.msg;
    if (msg.type !== 'license-validate') return;
    var id = e.detail.id;
    setTimeout(function () {
      _origDispatch(new CustomEvent('bloxflare-relay-response', {
        detail: {
          id: id,
          response: { ok: true, data: { valid: true, expires: null, discord: '', note: '' } }
        }
      }));
    }, 0);
  }, true);

  setTimeout(function () {
    try {
      _origDispatch(new CustomEvent('sora-auth-granted', {
        detail: { key: 'BYPASS', data: { valid: true, expires: null, discord: '', note: '' } }
      }));
    } catch (e) {}
  }, 0);
})();