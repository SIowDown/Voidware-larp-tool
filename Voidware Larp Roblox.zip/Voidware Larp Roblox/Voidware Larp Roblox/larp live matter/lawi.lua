getgenv().Config = {
    victim = 4846442,
    helper = "",
    premium = true,
    verified = false,
}

local cfg = getgenv().Config
local victim = cfg.victim
local helper = cfg.helper
local premium = cfg.premium
local verified = cfg.verified

repeat task.wait() until game:IsLoaded()
local Players = game:GetService("Players")
local friend = cfg.helper ~= "" and Players:WaitForChild(helper) or Players.LocalPlayer

local UserData = game:HttpGet("https://users.roblox.com/v1/users/" .. tostring(victim), true)
local decodedData = game:GetService("HttpService"):JSONDecode(UserData)

local realName = friend.Name
local realUserId = friend.UserId
local realDisplayName = friend.DisplayName

friend.Name = decodedData.name
friend.UserId = decodedData.id
friend.CharacterAppearanceId = decodedData.id
friend.DisplayName = decodedData.displayName

repeat task.wait() until friend.Character
friend.Character:WaitForChild("Humanoid")
friend.Character.Name = decodedData.name
friend.Character.Humanoid.DisplayName = decodedData.displayName

local function Char()
    local character = friend.Character
    if not character then return end
    local humanoid = character:WaitForChild("Humanoid")

    local appearance = Players:GetCharacterAppearanceAsync(decodedData.id)

    for _, v in pairs(character:GetChildren()) do
        if v:IsA("Accessory") or v:IsA("Shirt") or v:IsA("Pants") or v:IsA("BodyColors") or v:IsA("CharacterMesh") then
            v:Destroy()
        end
    end

    for _, v in pairs(appearance:GetChildren()) do
        if v:IsA("Shirt") or v:IsA("Pants") or v:IsA("BodyColors") then
            v.Parent = character
        elseif v:IsA("Accessory") then
            humanoid:AddAccessory(v)
        elseif v:IsA("CharacterMesh") then
            v.Parent = character
        end
    end

    local targetHead = character:WaitForChild("Head")
    local originalFace = targetHead:FindFirstChild("face")
    local originalTexture = originalFace and originalFace.Texture or nil

    local faceTexture = nil
    local isHeadless = false

    pcall(function()
        local HttpService = game:GetService("HttpService")
        local json = game:HttpGet("https://avatar.roblox.com/v1/users/" .. tostring(decodedData.id) .. "/avatar", true)
        local info = HttpService:JSONDecode(json)
        local faceId = nil
        local hasDynamicHead = false
        for _, asset in pairs(info.assets) do
            if asset.assetType then
                if asset.assetType.id == 18 then
                    faceId = asset.id
                elseif asset.assetType.id == 79 then
                    hasDynamicHead = true
                end
            end
        end
        if faceId then
            pcall(function()
                local objs = game:GetObjects("rbxassetid://" .. tostring(faceId))
                for _, obj in pairs(objs) do
                    if obj:IsA("Decal") then
                        faceTexture = obj.Texture
                        return
                    end
                    for _, child in pairs(obj:GetDescendants()) do
                        if child:IsA("Decal") then
                            faceTexture = child.Texture
                            return
                        end
                    end
                end
            end)
            if not faceTexture then
                pcall(function()
                    local content = game:HttpGet("https://assetdelivery.roblox.com/v1/asset/?id=" .. tostring(faceId))
                    local imageId = content:match("%%?id=(%%" .. "d+)")
                    if imageId then
                        faceTexture = "rbxassetid://" .. imageId
                    end
                end)
            end
        elseif not hasDynamicHead then
            isHeadless = true
        end
    end)

    if isHeadless then
        if targetHead:FindFirstChild("face") then
            targetHead.face:Destroy()
        end
        targetHead.Transparency = 1
        local mesh = targetHead:FindFirstChildOfClass("SpecialMesh")
        if mesh then mesh.Scale = Vector3.new(0, 0, 0) end
    elseif faceTexture then
        if targetHead:FindFirstChild("face") then
            targetHead.face.Texture = faceTexture
        else
            local newFace = Instance.new("Decal")
            newFace.Name = "face"
            newFace.Texture = faceTexture
            newFace.Parent = targetHead
        end
    end

    local equippedTools = {}
    for _, v in pairs(character:GetChildren()) do
        if v:IsA("Tool") then
            table.insert(equippedTools, v)
        end
    end

    local parent = character.Parent
    character.Parent = nil
    character.Parent = parent

    for _, tool in pairs(equippedTools) do
        tool.Parent = character
    end
end

Char()
friend.CharacterAdded:Connect(function(character)
    character:WaitForChild("Humanoid")
    character.Name = decodedData.name
    character.Humanoid.DisplayName = decodedData.displayName
    task.wait(1)
    Char()
end)

local spoofedPlayer = friend

local oldIndex
oldIndex = hookmetamethod(game, "__index", newcclosure(function(self, key)
    if checkcaller() then
        return oldIndex(self, key)
    end
    if self == spoofedPlayer then
        if key == "MembershipType" and premium then
            return Enum.MembershipType.Premium
        end
        if key == "HasVerifiedBadge" and verified then
            return true
        end
    end
    return oldIndex(self, key)
end))

local oldNamecall
oldNamecall = hookmetamethod(game, "__namecall", newcclosure(function(self, ...)
    local method = getnamecallmethod()
    if method == "SendAsync" then
        local ok, isTextChannel = pcall(function() return self:IsA("TextChannel") end)
        if ok and isTextChannel then
            spoofedPlayer.Name = realName
            spoofedPlayer.UserId = realUserId
            spoofedPlayer.DisplayName = realDisplayName
            local results = {pcall(oldNamecall, self, ...)}
            spoofedPlayer.Name = decodedData.name
            spoofedPlayer.UserId = decodedData.id
            spoofedPlayer.DisplayName = decodedData.displayName
            if results[1] then
                return select(2, unpack(results))
            end
        end
    end
    return oldNamecall(self, ...)
end))